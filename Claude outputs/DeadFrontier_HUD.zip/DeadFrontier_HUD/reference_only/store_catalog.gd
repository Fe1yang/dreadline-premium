extends RefCounted
## Real-money store: coin packs, voucher packs and bundles, priced in the player's own currency.
##
## Prices are App Store style price points. Each pack names a tier (its US price); every
## currency lists the matching local price for each tier, rounded the way stores show them
## (¥6 / ¥30 / ¥68 in China, ¥160 in Japan, R$ 5,90 in Brazil ...). The currency comes from the
## device region (OS.get_locale()), not the in-game language. The real charge is made by the
## App Store at checkout, so these are display prices and should be refreshed from StoreKit's
## localized prices once purchasing is connected (see main_3d.buy_pack).

const TIERS:=[0.99,1.99,4.99,9.99,19.99,49.99,99.99]

## id, art (res://assets/ui/store/<id>.png, goods only: the glow behind it is animated by hud.gd),
## coins, vouchers, price tier index, bonus %, kind, glow colour and number of light rays.
## One voucher opens one supply case, so vouchers are kept scarce.
const PACKS:=[
	{"id":"bundle_starter","kind":"bundle","name":"starter","coins":1000,"vouchers":1,"tier":1,"bonus":0,"once":true,"glow":"gold","rays":8},
	{"id":"bundle_supply","kind":"bundle","name":"supply","coins":4000,"vouchers":3,"tier":3,"bonus":0,"once":false,"glow":"amber","rays":12},
	{"id":"bundle_legend","kind":"bundle","name":"legend","coins":22000,"vouchers":12,"tier":5,"bonus":0,"once":false,"glow":"violet","rays":16},
	{"id":"coins_1","kind":"coins","coins":300,"vouchers":0,"tier":0,"bonus":0,"glow":"gold","rays":0},
	{"id":"coins_2","kind":"coins","coins":1650,"vouchers":0,"tier":2,"bonus":10,"glow":"gold","rays":6},
	{"id":"coins_3","kind":"coins","coins":3500,"vouchers":0,"tier":3,"bonus":17,"glow":"gold","rays":8},
	{"id":"coins_4","kind":"coins","coins":7400,"vouchers":0,"tier":4,"bonus":23,"glow":"amber","rays":10},
	{"id":"coins_5","kind":"coins","coins":19500,"vouchers":0,"tier":5,"bonus":30,"glow":"amber","rays":12},
	{"id":"coins_6","kind":"coins","coins":41000,"vouchers":0,"tier":6,"bonus":37,"glow":"red","rays":16},
	{"id":"vouchers_1","kind":"vouchers","coins":0,"vouchers":1,"tier":0,"bonus":0,"glow":"red","rays":0},
	{"id":"vouchers_2","kind":"vouchers","coins":0,"vouchers":6,"tier":2,"bonus":20,"glow":"red","rays":8},
	{"id":"vouchers_3","kind":"vouchers","coins":0,"vouchers":13,"tier":3,"bonus":30,"glow":"violet","rays":10},
	{"id":"vouchers_4","kind":"vouchers","coins":0,"vouchers":28,"tier":4,"bonus":40,"glow":"violet","rays":14},
]

## Limited-time offers: one pops up every two to three days (see main_3d.maybe_show_offer) and
## stays for OFFER_HOURS. "was" is the tier the contents would normally cost; the badge shows
## the saving between the two US prices.
const OFFER_HOURS:=6
const GLOW:={"gold":Color(1.0,0.72,0.25),"amber":Color(1.0,0.48,0.15),"red":Color(0.95,0.2,0.15),"violet":Color(0.62,0.32,1.0)}
const OFFERS:=[
	{"id":"offer_supply","kind":"offer","name":"offer_supply","coins":8000,"vouchers":2,"tier":2,"was":4,"bonus":0,"glow":"violet","rays":12},
	{"id":"offer_arms","kind":"offer","name":"offer_arms","coins":2000,"vouchers":8,"tier":3,"was":4,"bonus":0,"glow":"violet","rays":10},
	{"id":"offer_hoard","kind":"offer","name":"offer_hoard","coins":30000,"vouchers":10,"tier":4,"was":5,"bonus":0,"glow":"violet","rays":16},
]
static func offer(id: String) -> Dictionary:
	for o in OFFERS:
		if o.id==id: return o
	return {}

static func discount(o: Dictionary) -> int:
	return int(round((1.0-float(TIERS[int(o.tier)])/float(TIERS[int(o.was)]))*100.0))

## code: [symbol, symbol after the number?, decimals, decimal mark, thousands mark, prices per tier]
const CURRENCIES:={
	"USD":["$",false,2,".",",",[0.99,1.99,4.99,9.99,19.99,49.99,99.99]],
	"CNY":["¥",false,0,".",",",[6,12,30,68,128,328,648]],
	"JPY":["¥",false,0,".",",",[160,300,800,1500,3000,7800,15800]],
	"KRW":["₩",false,0,".",",",[1400,2900,7500,14000,29000,73000,149000]],
	"TWD":["NT$",false,0,".",",",[30,60,150,300,590,1490,2990]],
	"HKD":["HK$",false,0,".",",",[8,15,38,78,158,388,778]],
	"SGD":["S$",false,2,".",",",[1.48,2.98,6.98,13.98,27.98,68.98,138.98]],
	"EUR":["€",true,2,",",".",[0.99,1.99,4.99,9.99,19.99,49.99,99.99]],
	"GBP":["£",false,2,".",",",[0.99,1.99,4.99,9.99,19.99,49.99,99.99]],
	"RUB":["₽",true,0,","," ",[99,199,499,999,1990,4990,9990]],
	"UAH":["₴",true,0,","," ",[39,79,199,399,799,1999,3999]],
	"PLN":["zł",true,2,","," ",[4.99,9.99,24.99,49.99,99.99,249.99,499.99]],
	"TRY":["₺",false,2,",",".",[39.99,79.99,199.99,399.99,799.99,1999.99,3999.99]],
	"INR":["₹",false,0,".",",",[89,179,449,899,1799,4499,8999]],
	"IDR":["Rp",false,0,",",".",[16000,32000,79000,159000,319000,799000,1599000]],
	"THB":["฿",false,0,".",",",[35,69,179,349,699,1790,3590]],
	"VND":["₫",true,0,",",".",[25000,49000,129000,249000,499000,1290000,2490000]],
	"BRL":["R$",false,2,",",".",[5.90,11.90,29.90,59.90,119.90,299.90,599.90]],
	"MXN":["MX$",false,0,".",",",[19,39,99,199,399,999,1999]],
	"CAD":["CA$",false,2,".",",",[1.39,2.79,6.99,13.99,27.99,69.99,139.99]],
	"AUD":["A$",false,2,".",",",[1.49,2.99,7.99,15.99,29.99,79.99,159.99]],
	"SAR":["ر.س",true,2,".",",",[3.99,7.99,19.99,39.99,79.99,199.99,399.99]],
	"AED":["د.إ",true,2,".",",",[3.99,7.99,19.99,39.99,79.99,199.99,399.99]],
}
const REGION_CURRENCY:={
	"US":"USD","CN":"CNY","JP":"JPY","KR":"KRW","TW":"TWD","HK":"HKD","MO":"HKD","SG":"SGD",
	"GB":"GBP","RU":"RUB","UA":"UAH","PL":"PLN","TR":"TRY","IN":"INR","ID":"IDR","TH":"THB",
	"VN":"VND","BR":"BRL","MX":"MXN","CA":"CAD","AU":"AUD","SA":"SAR","AE":"AED",
	"DE":"EUR","FR":"EUR","ES":"EUR","IT":"EUR","NL":"EUR","PT":"EUR","BE":"EUR","AT":"EUR",
	"IE":"EUR","FI":"EUR","GR":"EUR","SK":"EUR","SI":"EUR","LT":"EUR","LV":"EUR","EE":"EUR",
	"LU":"EUR","MT":"EUR","CY":"EUR","HR":"EUR"}
## When the device gives a language but no region.
const LANGUAGE_CURRENCY:={"zh":"CNY","ja":"JPY","ko":"KRW","ru":"RUB","uk":"UAH","pl":"PLN",
	"tr":"TRY","hi":"INR","id":"IDR","th":"THB","vi":"VND","pt":"BRL","ar":"SAR",
	"de":"EUR","fr":"EUR","es":"EUR","it":"EUR","nl":"EUR"}

static func currency_for_locale(locale: String) -> String:
	var parts:=locale.replace("-","_").split("_")
	for i in range(parts.size()-1,0,-1):
		var region:=parts[i].to_upper()
		if REGION_CURRENCY.has(region): return REGION_CURRENCY[region]
		if region=="HANT": return "TWD"
	return LANGUAGE_CURRENCY.get(parts[0].to_lower(),"USD")

static func device_currency() -> String:
	return currency_for_locale(OS.get_locale())

static func pack(id: String) -> Dictionary:
	for p in PACKS:
		if p.id==id: return p
	return offer(id)

static func price_text(currency: String,tier: int) -> String:
	var c: Array=CURRENCIES.get(currency,CURRENCIES["USD"])
	return format_amount(c,float(c[5][clampi(tier,0,TIERS.size()-1)]))

static func format_amount(c: Array,amount: float) -> String:
	var decimals: int=c[2]
	var whole:=int(floor(amount+0.0001))
	var digits:=str(whole)
	var grouped:=""
	for i in range(digits.length()):
		if i>0 and (digits.length()-i)%3==0: grouped+=String(c[4])
		grouped+=digits[i]
	var number:=grouped
	if decimals>0:
		var frac:=int(round((amount-whole)*pow(10,decimals)))
		number+=String(c[3])+str(frac).pad_zeros(decimals)
	return (number+" "+String(c[0])) if bool(c[1]) else (String(c[0])+(" " if String(c[0]).length()>1 else "")+number)

## Store words for all 20 languages. Missing keys fall back to English.
const T:={
	"en":{"pay_failed":"Top-up failed","pay_failed_msg":"The purchase didn't go through and nothing was added. Check your connection and try again.","retry":"Retry","close":"Close","limited":"Limited offer","ends":"Ends in","was":"Was","offer_supply":"Supply drop","offer_arms":"Arms deal","offer_hoard":"Gold hoard","buy":"Buy","store":"Store","bundles":"Best value","coin_packs":"Coins","voucher_packs":"Vouchers","once":"Once only","owned":"Purchased","note":"Approximate local prices. The App Store charges the final amount.","pay_soon":"Payments are not connected yet","test_grant":"Test purchase: added","starter":"Starter pack","supply":"Supply pack","legend":"Legend pack","bonus":"bonus"},
	"zh_CN":{"pay_failed":"充值失败","pay_failed_msg":"本次购买没有完成，奖励未发放。请检查网络后重试。","retry":"重试","close":"关闭","limited":"限时礼包","ends":"剩余","was":"原价","offer_supply":"补给空投","offer_arms":"军火特惠","offer_hoard":"黄金宝藏","buy":"购买","store":"商店","bundles":"超值礼包","coin_packs":"金币","voucher_packs":"券","once":"限购一次","owned":"已购买","note":"价格为当地参考价，最终以 App Store 结算为准。","pay_soon":"支付功能尚未接入","test_grant":"测试购买：已到账","starter":"新手礼包","supply":"补给礼包","legend":"传奇礼包","bonus":"赠送"},
	"zh_TW":{"pay_failed":"儲值失敗","pay_failed_msg":"本次購買沒有完成，獎勵未發放。請檢查網路後重試。","retry":"重試","close":"關閉","limited":"限時禮包","ends":"剩餘","was":"原價","offer_supply":"補給空投","offer_arms":"軍火特惠","offer_hoard":"黃金寶藏","buy":"購買","store":"商店","bundles":"超值禮包","coin_packs":"金幣","voucher_packs":"券","once":"限購一次","owned":"已購買","note":"價格為當地參考價，最終以 App Store 結帳為準。","pay_soon":"支付功能尚未接入","test_grant":"測試購買：已到帳","starter":"新手禮包","supply":"補給禮包","legend":"傳奇禮包","bonus":"贈送"},
	"ja":{"pay_failed":"購入に失敗しました","pay_failed_msg":"購入が完了せず、アイテムは付与されていません。通信環境を確認して再度お試しください。","retry":"再試行","close":"閉じる","limited":"期間限定","ends":"残り","was":"通常","offer_supply":"補給投下","offer_arms":"武器特価","offer_hoard":"黄金の山","buy":"購入","store":"ショップ","bundles":"お得なパック","coin_packs":"コイン","voucher_packs":"チケット","once":"1回限り","owned":"購入済み","note":"価格は目安です。最終金額は App Store で確定します。","pay_soon":"決済はまだ接続されていません","test_grant":"テスト購入：付与しました","starter":"スターターパック","supply":"補給パック","legend":"レジェンドパック","bonus":"ボーナス"},
	"ko":{"pay_failed":"충전 실패","pay_failed_msg":"구매가 완료되지 않아 보상이 지급되지 않았습니다. 네트워크를 확인한 뒤 다시 시도하세요.","retry":"다시 시도","close":"닫기","limited":"기간 한정","ends":"남은 시간","was":"정가","offer_supply":"보급 투하","offer_arms":"무기 특가","offer_hoard":"황금 더미","buy":"구매","store":"상점","bundles":"특가 패키지","coin_packs":"코인","voucher_packs":"쿠폰","once":"1회 한정","owned":"구매 완료","note":"현지 참고 가격입니다. 최종 금액은 App Store에서 결제됩니다.","pay_soon":"결제가 아직 연결되지 않았습니다","test_grant":"테스트 구매: 지급 완료","starter":"스타터 팩","supply":"보급 팩","legend":"전설 팩","bonus":"보너스"},
	"es":{"pay_failed":"Error en la recarga","pay_failed_msg":"La compra no se completó y no se añadió nada. Revisa tu conexión e inténtalo de nuevo.","retry":"Reintentar","close":"Cerrar","limited":"Oferta limitada","ends":"Termina en","was":"Antes","offer_supply":"Suministros","offer_arms":"Trato de armas","offer_hoard":"Tesoro de oro","buy":"Comprar","store":"Tienda","bundles":"Mejor valor","coin_packs":"Monedas","voucher_packs":"Vales","once":"Solo una vez","owned":"Comprado","note":"Precios locales aproximados. El App Store cobra el importe final.","pay_soon":"Los pagos aún no están conectados","test_grant":"Compra de prueba: añadido","starter":"Pack inicial","supply":"Pack de suministros","legend":"Pack legendario","bonus":"extra"},
	"fr":{"pay_failed":"Échec de l'achat","pay_failed_msg":"L'achat n'a pas abouti et rien n'a été ajouté. Vérifie ta connexion et réessaie.","retry":"Réessayer","close":"Fermer","limited":"Offre limitée","ends":"Fin dans","was":"Avant","offer_supply":"Largage","offer_arms":"Offre d'armes","offer_hoard":"Trésor d'or","buy":"Acheter","store":"Boutique","bundles":"Meilleures offres","coin_packs":"Pièces","voucher_packs":"Bons","once":"Une seule fois","owned":"Acheté","note":"Prix locaux indicatifs. L'App Store facture le montant final.","pay_soon":"Les paiements ne sont pas encore connectés","test_grant":"Achat test : ajouté","starter":"Pack de départ","supply":"Pack de ravitaillement","legend":"Pack légendaire","bonus":"bonus"},
	"de":{"pay_failed":"Aufladen fehlgeschlagen","pay_failed_msg":"Der Kauf wurde nicht abgeschlossen, es wurde nichts gutgeschrieben. Prüfe deine Verbindung und versuche es erneut.","retry":"Erneut","close":"Schließen","limited":"Zeitangebot","ends":"Endet in","was":"Statt","offer_supply":"Nachschub","offer_arms":"Waffendeal","offer_hoard":"Goldschatz","buy":"Kaufen","store":"Shop","bundles":"Top-Angebote","coin_packs":"Münzen","voucher_packs":"Gutscheine","once":"Nur einmal","owned":"Gekauft","note":"Ungefähre lokale Preise. Der App Store berechnet den Endbetrag.","pay_soon":"Zahlungen sind noch nicht verbunden","test_grant":"Testkauf: gutgeschrieben","starter":"Startpaket","supply":"Nachschubpaket","legend":"Legendenpaket","bonus":"Bonus"},
	"pt":{"pay_failed":"Falha na recarga","pay_failed_msg":"A compra não foi concluída e nada foi adicionado. Verifique sua conexão e tente novamente.","retry":"Tentar de novo","close":"Fechar","limited":"Oferta limitada","ends":"Termina em","was":"Antes","offer_supply":"Suprimentos","offer_arms":"Oferta de armas","offer_hoard":"Tesouro","buy":"Comprar","store":"Loja","bundles":"Melhor valor","coin_packs":"Moedas","voucher_packs":"Vales","once":"Só uma vez","owned":"Comprado","note":"Preços locais aproximados. A App Store cobra o valor final.","pay_soon":"Os pagamentos ainda não estão conectados","test_grant":"Compra de teste: adicionado","starter":"Pacote inicial","supply":"Pacote de suprimentos","legend":"Pacote lendário","bonus":"bônus"},
	"ru":{"pay_failed":"Пополнение не удалось","pay_failed_msg":"Покупка не завершена, ничего не начислено. Проверь соединение и попробуй снова.","retry":"Повторить","close":"Закрыть","limited":"Акция","ends":"Осталось","was":"Было","offer_supply":"Сброс припасов","offer_arms":"Оружейная сделка","offer_hoard":"Золотой клад","buy":"Купить","store":"Магазин","bundles":"Выгодные наборы","coin_packs":"Монеты","voucher_packs":"Купоны","once":"Только один раз","owned":"Куплено","note":"Примерные местные цены. Итоговую сумму списывает App Store.","pay_soon":"Оплата пока не подключена","test_grant":"Тестовая покупка: начислено","starter":"Стартовый набор","supply":"Набор припасов","legend":"Легендарный набор","bonus":"бонус"},
	"ar":{"pay_failed":"فشل الشحن","pay_failed_msg":"لم تكتمل عملية الشراء ولم تتم إضافة شيء. تحقق من اتصالك وحاول مرة أخرى.","retry":"إعادة المحاولة","close":"إغلاق","limited":"عرض محدود","ends":"ينتهي خلال","was":"كان","offer_supply":"إمدادات","offer_arms":"صفقة أسلحة","offer_hoard":"كنز ذهبي","buy":"شراء","store":"المتجر","bundles":"أفضل قيمة","coin_packs":"العملات","voucher_packs":"القسائم","once":"مرة واحدة فقط","owned":"تم الشراء","note":"أسعار محلية تقريبية. يحتسب App Store المبلغ النهائي.","pay_soon":"الدفع غير متصل بعد","test_grant":"شراء تجريبي: تمت الإضافة","starter":"حزمة البداية","supply":"حزمة الإمدادات","legend":"الحزمة الأسطورية","bonus":"مكافأة"},
	"hi":{"pay_failed":"रीचार्ज विफल","pay_failed_msg":"खरीद पूरी नहीं हुई और कुछ नहीं जोड़ा गया। कनेक्शन जाँचें और फिर कोशिश करें।","retry":"फिर कोशिश","close":"बंद करें","limited":"सीमित ऑफ़र","ends":"खत्म होगा","was":"पहले","offer_supply":"सप्लाई ड्रॉप","offer_arms":"हथियार डील","offer_hoard":"सोने का खज़ाना","buy":"खरीदें","store":"स्टोर","bundles":"सबसे अच्छा सौदा","coin_packs":"सिक्के","voucher_packs":"वाउचर","once":"सिर्फ़ एक बार","owned":"खरीदा गया","note":"अनुमानित स्थानीय कीमतें। अंतिम राशि App Store लेता है।","pay_soon":"भुगतान अभी जुड़ा नहीं है","test_grant":"टेस्ट खरीद: जोड़ा गया","starter":"स्टार्टर पैक","supply":"सप्लाई पैक","legend":"लेजेंड पैक","bonus":"बोनस"},
	"id":{"pay_failed":"Isi ulang gagal","pay_failed_msg":"Pembelian tidak selesai dan tidak ada yang ditambahkan. Periksa koneksi lalu coba lagi.","retry":"Coba lagi","close":"Tutup","limited":"Penawaran terbatas","ends":"Berakhir","was":"Semula","offer_supply":"Pasokan","offer_arms":"Promo senjata","offer_hoard":"Harta emas","buy":"Beli","store":"Toko","bundles":"Paling hemat","coin_packs":"Koin","voucher_packs":"Voucher","once":"Hanya sekali","owned":"Dibeli","note":"Perkiraan harga lokal. App Store menagih jumlah akhir.","pay_soon":"Pembayaran belum terhubung","test_grant":"Pembelian uji: ditambahkan","starter":"Paket pemula","supply":"Paket pasokan","legend":"Paket legenda","bonus":"bonus"},
	"it":{"pay_failed":"Ricarica non riuscita","pay_failed_msg":"L'acquisto non è andato a buon fine e non è stato aggiunto nulla. Controlla la connessione e riprova.","retry":"Riprova","close":"Chiudi","limited":"Offerta limitata","ends":"Scade tra","was":"Prima","offer_supply":"Rifornimenti","offer_arms":"Affare armi","offer_hoard":"Tesoro d'oro","buy":"Compra","store":"Negozio","bundles":"Offerte migliori","coin_packs":"Monete","voucher_packs":"Buoni","once":"Una sola volta","owned":"Acquistato","note":"Prezzi locali indicativi. L'App Store addebita l'importo finale.","pay_soon":"I pagamenti non sono ancora collegati","test_grant":"Acquisto di prova: aggiunto","starter":"Pacchetto iniziale","supply":"Pacchetto rifornimenti","legend":"Pacchetto leggendario","bonus":"bonus"},
	"tr":{"pay_failed":"Yükleme başarısız","pay_failed_msg":"Satın alma tamamlanmadı ve hiçbir şey eklenmedi. Bağlantını kontrol edip tekrar dene.","retry":"Tekrar dene","close":"Kapat","limited":"Sınırlı teklif","ends":"Bitiş","was":"Önce","offer_supply":"İkmal","offer_arms":"Silah fırsatı","offer_hoard":"Altın hazinesi","buy":"Satın al","store":"Mağaza","bundles":"En iyi fırsat","coin_packs":"Altın","voucher_packs":"Kuponlar","once":"Yalnızca bir kez","owned":"Satın alındı","note":"Yaklaşık yerel fiyatlar. Son tutarı App Store tahsil eder.","pay_soon":"Ödemeler henüz bağlı değil","test_grant":"Test satın alma: eklendi","starter":"Başlangıç paketi","supply":"İkmal paketi","legend":"Efsane paketi","bonus":"bonus"},
	"nl":{"pay_failed":"Opwaarderen mislukt","pay_failed_msg":"De aankoop is niet gelukt en er is niets toegevoegd. Controleer je verbinding en probeer het opnieuw.","retry":"Opnieuw","close":"Sluiten","limited":"Tijdelijk aanbod","ends":"Eindigt over","was":"Was","offer_supply":"Voorraaddrop","offer_arms":"Wapendeal","offer_hoard":"Goudschat","buy":"Kopen","store":"Winkel","bundles":"Beste deals","coin_packs":"Munten","voucher_packs":"Bonnen","once":"Eenmalig","owned":"Gekocht","note":"Geschatte lokale prijzen. De App Store rekent het eindbedrag af.","pay_soon":"Betalingen zijn nog niet gekoppeld","test_grant":"Testaankoop: toegevoegd","starter":"Startpakket","supply":"Voorraadpakket","legend":"Legendepakket","bonus":"bonus"},
	"pl":{"pay_failed":"Doładowanie nieudane","pay_failed_msg":"Zakup nie został zakończony i nic nie dodano. Sprawdź połączenie i spróbuj ponownie.","retry":"Ponów","close":"Zamknij","limited":"Oferta czasowa","ends":"Koniec za","was":"Było","offer_supply":"Zrzut zapasów","offer_arms":"Okazja zbrojna","offer_hoard":"Złoty skarb","buy":"Kup","store":"Sklep","bundles":"Najlepsze oferty","coin_packs":"Monety","voucher_packs":"Kupony","once":"Tylko raz","owned":"Kupiono","note":"Przybliżone ceny lokalne. Ostateczną kwotę pobiera App Store.","pay_soon":"Płatności nie są jeszcze podłączone","test_grant":"Zakup testowy: dodano","starter":"Pakiet startowy","supply":"Pakiet zaopatrzenia","legend":"Pakiet legendarny","bonus":"bonus"},
	"th":{"pay_failed":"เติมเงินไม่สำเร็จ","pay_failed_msg":"การซื้อไม่สำเร็จและยังไม่ได้รับของรางวัล ตรวจสอบการเชื่อมต่อแล้วลองอีกครั้ง","retry":"ลองอีกครั้ง","close":"ปิด","limited":"ข้อเสนอจำกัดเวลา","ends":"เหลือ","was":"ปกติ","offer_supply":"เสบียงด่วน","offer_arms":"อาวุธราคาพิเศษ","offer_hoard":"ขุมทองคำ","buy":"ซื้อ","store":"ร้านค้า","bundles":"แพ็กคุ้มค่า","coin_packs":"เหรียญ","voucher_packs":"คูปอง","once":"ซื้อได้ครั้งเดียว","owned":"ซื้อแล้ว","note":"ราคาท้องถิ่นโดยประมาณ ยอดสุดท้ายเรียกเก็บโดย App Store","pay_soon":"ยังไม่ได้เชื่อมต่อการชำระเงิน","test_grant":"ซื้อทดสอบ: เพิ่มแล้ว","starter":"แพ็กเริ่มต้น","supply":"แพ็กเสบียง","legend":"แพ็กตำนาน","bonus":"โบนัส"},
	"vi":{"pay_failed":"Nạp thất bại","pay_failed_msg":"Giao dịch chưa hoàn tất và chưa nhận được gì. Hãy kiểm tra kết nối rồi thử lại.","retry":"Thử lại","close":"Đóng","limited":"Ưu đãi có hạn","ends":"Còn","was":"Giá gốc","offer_supply":"Tiếp tế","offer_arms":"Ưu đãi vũ khí","offer_hoard":"Kho vàng","buy":"Mua","store":"Cửa hàng","bundles":"Giá trị nhất","coin_packs":"Xu","voucher_packs":"Phiếu","once":"Chỉ một lần","owned":"Đã mua","note":"Giá địa phương tham khảo. App Store tính số tiền cuối cùng.","pay_soon":"Chưa kết nối thanh toán","test_grant":"Mua thử: đã cộng","starter":"Gói khởi đầu","supply":"Gói tiếp tế","legend":"Gói huyền thoại","bonus":"thưởng"},
	"uk":{"pay_failed":"Поповнення не вдалося","pay_failed_msg":"Покупку не завершено, нічого не нараховано. Перевір з'єднання і спробуй ще раз.","retry":"Повторити","close":"Закрити","limited":"Акція","ends":"Залишилось","was":"Було","offer_supply":"Скидання припасів","offer_arms":"Збройова угода","offer_hoard":"Золотий скарб","buy":"Купити","store":"Крамниця","bundles":"Вигідні набори","coin_packs":"Монети","voucher_packs":"Купони","once":"Лише один раз","owned":"Придбано","note":"Орієнтовні місцеві ціни. Остаточну суму списує App Store.","pay_soon":"Оплату ще не підключено","test_grant":"Тестова покупка: зараховано","starter":"Стартовий набір","supply":"Набір припасів","legend":"Легендарний набір","bonus":"бонус"},
}

static func text(code: String,key: String) -> String:
	var table: Dictionary=T.get(code,T["en"])
	return String(table.get(key,T["en"].get(key,key)))
