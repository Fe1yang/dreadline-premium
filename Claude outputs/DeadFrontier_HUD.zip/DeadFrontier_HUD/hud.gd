extends Control

const ShopText=preload("res://scripts/shop_text.gd")
const Localization=preload("res://scripts/localization.gd")
const GameText=preload("res://scripts/game_text.gd")
const StoreCatalog=preload("res://scripts/store_catalog.gd")
const ProgressCatalog=preload("res://scripts/progress_catalog.gd")
const INK=Color("0b0e0f")
const HEART=Color("a3201f")
const GrungeShader=preload("res://shaders/ui_grunge.gdshader")
const PANEL=Color("15191a")
const WHITE=Color("f6f6f3")
const MUTED=Color("b3b8b6")
const LINE=Color("4b5050")
const RED=Color("b6383e")
const GOLD=Color("d8b56c")
const ARMOR=Color("83b4c0")
# Dead Island palette: charcoal plates, blood red kept for section splashes and the ONE main
# action per screen, aged brass for anything that costs money or plays an ad.
const BRASS:=Color("a8863c")          # aged brass (ad buttons, purchase frames)
const BRASS_LIGHT:=Color("e0bd72")    # brass lettering on dark plates
const BRASS_INK:=Color("1c1508")      # dark text on brass
const PLATE:=Color(0.075,0.08,0.082,0.90)   # standard flat panel
const PLATE_DIM:=Color(0.05,0.055,0.058,0.86)

var game: Node
var font: Font
var bold: Font
var portraits: Array[Texture2D]=[]
var pet_portraits: Array[Texture2D]=[]
var coin_tex: Texture2D
var voucher_tex: Texture2D
var pack_art:={}
var glow_tex: GradientTexture2D
var hud_portraits: Array[Texture2D]=[]
var menu_art: Texture2D
# Small print and photos are drawn on a child layer without the worn-paint shader so they stay legible.
const CLEAN_TEXT_BELOW:=28 # Latin text smaller than this stays clean
const CLEAN_CJK_BELOW:=44 # dense CJK glyphs need to be much larger before wear is readable
var clean: Control
var clean_ops: Array=[]
## Scrolling lists (store) draw into their own clipped layer under the clean layer, so rows are
## cut off cleanly at the list edges while the dimmed scene still shows behind the header.
var list_clip: Control
var list_ops: Array=[]
var grunge_tex: Texture2D
# Hand-painted brush strokes used for every panel and button (assets/ui/brush_*.png, white
# alpha masks tinted at draw time) instead of thin outlined boxes.
var brush_button: Array[Texture2D]=[]
var brush_panel: Array[Texture2D]=[]
var brush_line: Array[Texture2D]=[]
const PAINT_RED:=Color("a8201c")
const PAINT_DARK:=Color(0.055,0.06,0.062,0.94)
var cjk: SystemFont
var cjk_black: FontFile
var bold_base: FontFile
var cjk_language:=""
const CJK_FONTS:={
	"zh_CN":["Microsoft YaHei","PingFang SC","Noto Sans CJK SC","Source Han Sans SC","Noto Sans SC"],
	"zh_TW":["Microsoft JhengHei","PingFang TC","Noto Sans CJK TC","Source Han Sans TC","Noto Sans TC"],
	"ja":["Yu Gothic UI","Hiragino Sans","Noto Sans CJK JP","Meiryo","Noto Sans JP"],
	"ko":["Malgun Gothic","Apple SD Gothic Neo","Noto Sans CJK KR","Noto Sans KR"]}

func _update_cjk_font() -> void:
	var code: String=game.language_code if game!=null else "zh_CN"
	if code==cjk_language or cjk==null: return
	cjk_language=code
	cjk.font_names=PackedStringArray(CJK_FONTS.get(code,CJK_FONTS["zh_CN"]))
	# The bundled heavy face has Simplified glyph shapes, so only Simplified Chinese uses it.
	if bold_base and cjk_black: bold_base.fallbacks=[cjk_black,cjk,font.fallbacks[-1]] if code=="zh_CN" else [cjk,font.fallbacks[-1]]

func _ready() -> void:
	var system:=SystemFont.new()
	system.font_names=PackedStringArray(["Noto Sans","Segoe UI","Arial"])
	system.allow_system_fallback=true
	# Condensed poster lettering for all UI text. Han characters go to a CJK font picked for the
	# current language first, so Simplified Chinese never borrows Japanese or Traditional glyph shapes.
	cjk=SystemFont.new(); cjk.allow_system_fallback=true
	var display:=load("res://assets/fonts/hud_condensed_bold.otf") as FontFile
	display.fallbacks=[cjk,system]
	font=display
	# Headings and buttons: separate copy whose Chinese falls back to a heavy poster-weight face
	# (Noto Sans CJK SC Black, bundled) instead of the thin system font.
	bold_base=display.duplicate() as FontFile
	cjk_black=load("res://assets/fonts/hud_cjk_black.otf") as FontFile
	bold_base.fallbacks=[cjk_black,cjk,system]
	var heavy:=FontVariation.new(); heavy.base_font=bold_base; heavy.variation_embolden=0.35; bold=heavy
	# Worn paint look on every bright stroke (see shaders/ui_grunge.gdshader).
	var grunge:=ShaderMaterial.new(); grunge.shader=GrungeShader
	grunge.set_shader_parameter("grunge",load("res://assets/ui/ui_grunge.png"))
	material=grunge
	list_clip=Control.new(); list_clip.mouse_filter=Control.MOUSE_FILTER_IGNORE; list_clip.clip_contents=true
	add_child(list_clip); list_clip.draw.connect(_draw_list)
	grunge_tex=load("res://assets/ui/ui_grunge.png")
	clean=Control.new(); clean.mouse_filter=Control.MOUSE_FILTER_IGNORE
	clean.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(clean); clean.draw.connect(_draw_clean)
	portraits=[load("res://assets/ui/male_hd_portrait.png"),load("res://assets/ui/female_hd_portrait.png")]
	pet_portraits=[load("res://assets/ui/pets/doberman.png"),load("res://assets/ui/pets/german_shepherd.png"),load("res://assets/ui/pets/czech_wolfdog.png"),load("res://assets/ui/pets/tibetan_mastiff.png")]
	coin_tex=load("res://assets/ui/currency/coin.png"); voucher_tex=load("res://assets/ui/currency/voucher.png")
	for p in StoreCatalog.PACKS+StoreCatalog.OFFERS: pack_art[p.id]=load("res://assets/ui/store/%s.png"%p.id)
	var grad:=Gradient.new(); grad.set_color(0,Color(1,1,1,1)); grad.set_color(1,Color(1,1,1,0)); grad.add_point(0.45,Color(1,1,1,0.45))
	glow_tex=GradientTexture2D.new(); glow_tex.gradient=grad; glow_tex.fill=GradientTexture2D.FILL_RADIAL; glow_tex.fill_from=Vector2(0.5,0.5); glow_tex.fill_to=Vector2(1.0,0.5); glow_tex.width=128; glow_tex.height=128
	hud_portraits=[load("res://assets/ui/male_hud_gray.png"),load("res://assets/ui/female_hud_gray.png")]
	menu_art=load("res://assets/ui/title_screen.png")
	for i in range(3):
		brush_button.append(load("res://assets/ui/brush_button_%d.png"%i))
		brush_panel.append(load("res://assets/ui/brush_panel_%d.png"%i))
		brush_line.append(load("res://assets/ui/brush_line_%d.png"%i))

func _process(_delta: float) -> void:
	_update_cjk_font()
	# The title poster already has its own distressed lettering, so leave it untouched.
	if material: (material as ShaderMaterial).set_shader_parameter("strength",0.0 if game!=null and game.state=="menu" else 1.0)
	queue_redraw()

func _draw() -> void:
	clean_ops.clear(); list_ops.clear()
	if game==null or font==null: return
	if game.state in ["playing","paused"]: _draw_hud()
	elif game.state=="intro": _draw_intro()
	elif game.state=="menu": _draw_menu()
	elif game.state=="gameover": _draw_hud(); clean_ops.clear(); _draw_gameover()
	elif game.state=="shop": _draw_shop()
	elif game.state=="lootbox": _draw_lootbox()
	elif game.state=="language": _draw_languages()
	elif game.state=="settings": _draw_settings()
	elif game.state=="store": _draw_store()
	elif game.state=="offer":
		match game.offer_return_state:
			"store": _draw_store()
			"shop": _draw_shop()
			_: _draw_character_select()
		_draw_offer_popup()
	elif game.state=="payfail":
		match game.payfail_return_state:
			"store": _draw_store()
			"offer":
				if game.offer_return_state=="store": _draw_store()
				else: _draw_character_select()
				_draw_offer_popup()
			_: _draw_character_select()
		_draw_payfail()
	elif game.state=="signin":
		_draw_character_select(); _draw_signin()
	elif game.state=="tasks": _draw_tasks()
	elif game.state=="character_select": _draw_character_select()
	if game.state=="paused": clean_ops.clear(); _draw_pause() # HUD small print sits under the overlay
	if game.damage_flash>0: draw_rect(Rect2(0,0,540,960),Color(0.65,0.025,0.025,game.damage_flash*0.36))
	draw_rect(Rect2(0,0,540,2),Color(0.45,0.04,0.055,0.65))
	if clean: clean.queue_redraw()
	if list_clip: list_clip.queue_redraw()

func _draw_clean() -> void:
	_replay(clean,clean_ops,Vector2.ZERO)

func _draw_list() -> void:
	_replay(list_clip,list_ops,-list_clip.position)

## Draws recorded ops onto a layer. "xf" sets a rotation/offset for what follows (tilted tags).
func _replay(target: Control,ops: Array,offset: Vector2) -> void:
	target.draw_set_transform(offset,0.0,Vector2.ONE)
	for op in ops:
		match op[0]:
			"text": target.draw_string(op[1],op[2],op[3],HORIZONTAL_ALIGNMENT_LEFT,-1,op[4],op[5])
			"texture": target.draw_texture_rect(op[1],op[2],false)
			"region": target.draw_texture_rect_region(op[1],op[2],op[3])
			"tinted": target.draw_texture_rect(op[1],op[2],false,op[3])
			"tiled": target.draw_texture_rect(op[1],op[2],true,op[3])
			"box": target.draw_style_box(op[1],op[2])
			"poly": target.draw_colored_polygon(op[1],op[2])
			"line": target.draw_polyline(op[1],op[2],op[3],true)
			"xf": target.draw_set_transform(offset+op[1],op[2],Vector2.ONE)
			"xf0": target.draw_set_transform(offset,0.0,Vector2.ONE)
			"grad": target.draw_polygon(op[1],op[2])

## Player text-size setting (small / medium / large). Small print is scaled most, since that is
## what is hard to read; big headlines barely change so layouts still fit.
func _scaled(size: int) -> int:
	var choice: int=game.text_size if game!=null else 1
	var factor: float=[0.9,1.0,1.25][choice]
	if size>=40: factor=1.0+(factor-1.0)*0.4
	return maxi(8,roundi(size*factor))

func _string(f: Font,pos: Vector2,value: String,size: int,color: Color) -> void:
	size=_scaled(size)
	var limit:=CLEAN_TEXT_BELOW
	for i in range(value.length()):
		if value.unicode_at(i)>0x2E7F: limit=CLEAN_CJK_BELOW; break
	if size<limit: clean_ops.append(["text",f,pos,value,size,color])
	else: draw_string(f,pos,value,HORIZONTAL_ALIGNMENT_LEFT,-1,size,color)

func _draw_intro() -> void:
	draw_rect(Rect2(0,0,540,78),Color(0.01,0.012,0.013,0.94))
	draw_rect(Rect2(0,852,540,108),Color(0.01,0.012,0.013,0.94))
	if game.intro_time<1.4:
		_text_center("追杀者来了" if game.language_code.begins_with("zh") else "THE CHASER IS COMING",Vector2(270,902),30,WHITE)
	else:
		_text_center("跑！不要回头" if game.language_code.begins_with("zh") else "RUN! DON'T LOOK BACK",Vector2(270,902),30,WHITE)
	_text_center("点击跳过" if game.language_code.begins_with("zh") else "TAP TO SKIP",Vector2(270,936),12,MUTED)

func _draw_hud() -> void:
	# Minimal survival HUD: hearts top-left, distance and kills top-centre, ammo and pause top-right.
	for i in range(36):
		draw_rect(Rect2(0,i*4,540,4),Color(0,0,0,0.34*(1.0-i/36.0)))
	_draw_hearts(Vector2(26,22))
	if game.player.has_armor: _draw_armor_badge(Vector2(26,66))
	var dist:=_group_thousands(int(game.distance))
	var num_w:=bold.get_string_size(dist,HORIZONTAL_ALIGNMENT_LEFT,-1,62).x
	var unit_w:=bold.get_string_size("m",HORIZONTAL_ALIGNMENT_LEFT,-1,34).x
	var x0:=270.0-(num_w+8+unit_w)/2.0
	# Past the old best the counter turns gold; close to it, a reminder of how far is left.
	var dist_col: Color=Color("ffd36b") if game.new_record else WHITE
	draw_string(bold,Vector2(x0,78),dist,HORIZONTAL_ALIGNMENT_LEFT,-1,62,dist_col)
	draw_string(bold,Vector2(x0+num_w+8,78),"m",HORIZONTAL_ALIGNMENT_LEFT,-1,34,dist_col)
	var lang_r: String=game.language_code
	if not game.new_record and game.run_start_best>0 and game.record_metres_left()<=game.RECORD_HINT_METRES:
		_clean_center(bold,Vector2(270,156),ProgressCatalog.text(lang_r,"rec_left").replace("%d",str(game.record_metres_left())),16,Color("ffd36b"))
	_draw_skull(Vector2(244,118),17)
	draw_string(bold,Vector2(268,133),"x %d"%game.kills,HORIZONTAL_ALIGNMENT_LEFT,-1,36,WHITE)
	_draw_pause_button(PAUSE_RECT)
	if game.record_banner>0.0: _draw_record_banner()
	_draw_ammo(Vector2(470,52))
	if game.touch_controls and game.state=="playing":
		_draw_joystick(game.left_origin,game.left_knob,false)
		_draw_joystick(game.right_origin,game.right_knob,true)
		_round_button(game.BTN_RELOAD,"reload",-1,WHITE)
		var swap_to: String=game.player.swap_target()
		_round_button(game.BTN_SWAP,"swap",-1,WHITE if swap_to!="" else Color(1,1,1,0.35))
		if swap_to!="":
			var short:={"PISTOL":"PST","SMG":"SMG","SHOTGUN":"SG","SNIPER":"SNP","RIFLE":"AR","LAUNCHER":"GL"}
			_text_center(short.get(swap_to,swap_to),game.BTN_SWAP+Vector2(0,52),13,WHITE)
		_round_button(game.BTN_FRAG,"frag",game.player.grenade_count,WHITE)
		_round_button(game.BTN_FLASH,"flash",game.player.flashbang_count,Color("cfefff"))
		if game.player.weapon=="LAUNCHER":
			_round_button(game.BTN_FIRE_MODE,"fire",game.player.fire_ammo,Color("ff8a5c"))
	if game.hint_time>0:
		var hint: String=game.localize("aim_stick") if game.touch_controls else GameText.text(game.language_code,"auto_hint")
		_text_center(hint,Vector2(270,186),15,Color(WHITE.r,WHITE.g,WHITE.b,clampf(game.hint_time,0,1)*0.9))
	if game.wave_banner>0:
		var a: float=minf(1,game.wave_banner)
		draw_rect(Rect2(232,214,76,3),Color(0.71,0.12,0.15,a))
		_text_center(game.localize("wave")+" %02d"%game.wave,Vector2(270,256),40,Color(WHITE.r,WHITE.g,WHITE.b,a))
	# (No on-screen name for the Banshee: she just turns up, like any other zombie.)

const PAUSE_RECT:=Rect2(482,14,46,46) # drawn box; the tap area is game.PAUSE_BUTTON

func _group_thousands(value: int) -> String:
	var digits:=str(value); var out:=""
	for i in range(digits.length()):
		if i>0 and (digits.length()-i)%3==0: out+=","
		out+=digits[i]
	return out

func _heart_points(center: Vector2,size: float) -> PackedVector2Array:
	var pts:=PackedVector2Array()
	for i in range(48):
		var t:=TAU*i/48.0
		var x:=16.0*pow(sin(t),3.0)
		var y:=13.0*cos(t)-5.0*cos(2.0*t)-2.0*cos(3.0*t)-cos(4.0*t)
		pts.append(center+Vector2(x,-y)*size/34.0)
	return pts

func _draw_hearts(origin: Vector2) -> void:
	var hp: float=clampf(game.player.health/game.player.max_health,0.0,1.0)*3.0
	for i in range(3):
		var c:=origin+Vector2(18+i*38,14)
		var shape:=_heart_points(c,34)
		draw_colored_polygon(shape,Color(0.05,0.03,0.03,0.55))
		var fill:=clampf(hp-i,0.0,1.0)
		if fill>=0.999: draw_colored_polygon(shape,HEART)
		elif fill>0.0:
			var clip:=PackedVector2Array([c+Vector2(-20,-20),c+Vector2(-20+40*fill,-20),c+Vector2(-20+40*fill,20),c+Vector2(-20,20)])
			for part in Geometry2D.intersect_polygons(shape,clip): draw_colored_polygon(part,HEART)
		shape.append(shape[0]); draw_polyline(shape,Color(0.02,0.01,0.01,0.75),1.5,true)

func _draw_armor_badge(pos: Vector2) -> void:
	var shield:=PackedVector2Array([pos+Vector2(0,0),pos+Vector2(16,-4),pos+Vector2(32,0),pos+Vector2(30,18),pos+Vector2(16,30),pos+Vector2(2,18)])
	draw_colored_polygon(shield,Color(0.30,0.48,0.54,0.95)); shield.append(shield[0]); draw_polyline(shield,WHITE,1.5,true)
	_text("ARMOR",pos+Vector2(40,22),16,ARMOR)

func _draw_skull(c: Vector2,r: float) -> void:
	draw_circle(c+Vector2(0,-r*0.12),r,WHITE)
	draw_rect(Rect2(c+Vector2(-r*0.58,r*0.45),Vector2(r*1.16,r*0.62)),WHITE)
	draw_circle(c+Vector2(-r*0.40,-r*0.05),r*0.30,INK); draw_circle(c+Vector2(r*0.40,-r*0.05),r*0.30,INK)
	draw_colored_polygon(PackedVector2Array([c+Vector2(0,r*0.25),c+Vector2(-r*0.13,r*0.48),c+Vector2(r*0.13,r*0.48)]),INK)
	for k in range(3): draw_line(c+Vector2(-r*0.30+k*r*0.30,r*0.62),c+Vector2(-r*0.30+k*r*0.30,r*1.05),INK,2)

func _draw_pause_button(rect: Rect2) -> void:
	# Plain rounded frame like the round control buttons (no brush underline under it).
	var box:=StyleBoxFlat.new(); box.bg_color=Color(0,0,0,0.30); box.border_color=WHITE
	box.set_border_width_all(2); box.set_corner_radius_all(6); draw_style_box(box,rect)
	draw_rect(Rect2(rect.position+Vector2(15,12),Vector2(5,22)),WHITE)
	draw_rect(Rect2(rect.position+Vector2(26,12),Vector2(5,22)),WHITE)

func _draw_ammo(right_top: Vector2) -> void:
	# "12/48" plus a cartridge icon, right-aligned beside the pause button.
	var label:="%d/∞"%game.player.ammo if game.player.infinite_ammo() else "%d/%d"%[game.player.ammo,game.player.reserve_ammo]
	var w:=bold.get_string_size(label,HORIZONTAL_ALIGNMENT_LEFT,-1,34).x
	var bullet_x:=right_top.x-12
	draw_string(bold,Vector2(bullet_x-14-w,right_top.y),label,HORIZONTAL_ALIGNMENT_LEFT,-1,34,WHITE if game.player.ammo>0 else Color("e66b62"))
	draw_rect(Rect2(bullet_x-4,right_top.y-22,9,20),WHITE)
	draw_colored_polygon(PackedVector2Array([Vector2(bullet_x-4,right_top.y-22),Vector2(bullet_x+0.5,right_top.y-34),Vector2(bullet_x+5,right_top.y-22)]),WHITE)
	draw_rect(Rect2(bullet_x-5,right_top.y-4,11,4),WHITE)
	var weapon_label: String=game.player.weapon
	if game.player.weapon=="LAUNCHER": weapon_label+="  ·  "+("INC x%d"%game.player.fire_ammo if game.player.fire_mode else "FRAG")
	_text_right(weapon_label,Vector2(right_top.x+6,right_top.y+26),16,MUTED)
	if not game.touch_controls:
		_text_right("G x%d   F x%d"%[game.player.grenade_count,game.player.flashbang_count],Vector2(right_top.x+6,right_top.y+48),15,MUTED)
	if game.player.reloading:
		var progress: float=1.0-game.player.reload_timer/game.player.reload_duration
		draw_rect(Rect2(Vector2(right_top.x-110,right_top.y+60),Vector2(116,3)),Color(1,1,1,0.18))
		draw_rect(Rect2(Vector2(right_top.x-110,right_top.y+60),Vector2(116*progress,3)),RED)
		_text_right(game.localize("loading"),Vector2(right_top.x+6,right_top.y+84),15,WHITE)
	elif game.player.ammo==0:
		_text_right(game.localize("auto") if game.auto_reload else game.localize("press_r"),Vector2(right_top.x+6,right_top.y+84),15,Color("e66b62"))

func _round_button(center: Vector2,icon: String,count: int,accent: Color) -> void:
	var r:=34.0
	draw_circle(center,r,Color(0.02,0.02,0.02,0.45))
	draw_arc(center,r,0,TAU,48,WHITE,2.5,true)
	match icon:
		"reload":
			draw_arc(center,15,deg_to_rad(200),deg_to_rad(340),20,WHITE,4,true)
			draw_arc(center,15,deg_to_rad(20),deg_to_rad(160),20,WHITE,4,true)
			var a:=center+Vector2(15,0).rotated(deg_to_rad(340)); var b:=center+Vector2(15,0).rotated(deg_to_rad(160))
			draw_colored_polygon(PackedVector2Array([a+Vector2(-6,-6),a+Vector2(6,-4),a+Vector2(1,7)]),WHITE)
			draw_colored_polygon(PackedVector2Array([b+Vector2(6,6),b+Vector2(-6,4),b+Vector2(-1,-7)]),WHITE)
		"frag":
			draw_circle(center+Vector2(0,4),13,WHITE)
			for k in range(3): draw_line(center+Vector2(-12,-1+k*6),center+Vector2(12,-1+k*6),INK,1.5)
			draw_line(center+Vector2(0,-9),center+Vector2(0,13),INK,1.5)
			draw_rect(Rect2(center+Vector2(-5,-15),Vector2(10,7)),WHITE)
			draw_arc(center+Vector2(9,-12),5,PI*0.5,PI*1.8,10,WHITE,2,true)
		"flash":
			draw_rect(Rect2(center+Vector2(-9,-10),Vector2(18,24)),accent)
			draw_rect(Rect2(center+Vector2(-5,-16),Vector2(10,6)),accent)
			for k in range(3): draw_line(center+Vector2(-9,-4+k*7),center+Vector2(9,-4+k*7),INK,1.5)
		"swap":
			# Two opposing arrows: switch guns.
			draw_line(center+Vector2(-13,-6),center+Vector2(11,-6),accent,3.5)
			draw_colored_polygon(PackedVector2Array([center+Vector2(15,-6),center+Vector2(7,-12),center+Vector2(7,0)]),accent)
			draw_line(center+Vector2(13,7),center+Vector2(-11,7),accent,3.5)
			draw_colored_polygon(PackedVector2Array([center+Vector2(-15,7),center+Vector2(-7,1),center+Vector2(-7,13)]),accent)
		"fire":
			draw_colored_polygon(PackedVector2Array([center+Vector2(0,-17),center+Vector2(11,4),center+Vector2(0,15),center+Vector2(-11,4)]),accent)
			draw_colored_polygon(PackedVector2Array([center+Vector2(0,-4),center+Vector2(5,6),center+Vector2(0,11),center+Vector2(-5,6)]),INK)
	if count>=0:
		draw_circle(center+Vector2(24,24),11,Color(0.05,0.05,0.05,0.85)); draw_arc(center+Vector2(24,24),11,0,TAU,24,accent,1.5,true)
		_text_center(str(count),center+Vector2(24,30),16,WHITE)

func _draw_joystick(origin: Vector2,knob: Vector2,aim: bool) -> void:
	# Two matching thumbsticks: left steers left/right, right turns the survivor (aim).
	draw_circle(origin,62,Color(0.02,0.02,0.02,0.28))
	draw_arc(origin,62,0,TAU,72,WHITE,3,true)
	if aim:
		# Tick marks all the way round: this stick points the survivor in any direction.
		for i in range(12):
			var a:=i*TAU/12.0; var dir:=Vector2(cos(a),sin(a))
			draw_line(origin+dir*50,origin+dir*(57 if i%3 else 44),WHITE,2.5 if i%3 else 3.0)
	else:
		# Only left and right arrows: this stick only moves the survivor sideways.
		for d in [Vector2.LEFT,Vector2.RIGHT]:
			var dir: Vector2=d; var tip: Vector2=origin+dir*50; var side:=Vector2(-dir.y,dir.x)*8
			draw_colored_polygon(PackedVector2Array([tip,tip-dir*12+side,tip-dir*12-side]),WHITE)
	# Both sticks get the same grey thumb knob.
	draw_circle(knob,26,Color(0.62,0.62,0.60,0.92)); draw_arc(knob,26,0,TAU,40,WHITE,2,true)
	if aim:
		# Small sight on the knob so the two sticks are still easy to tell apart.
		for d: Vector2 in [Vector2.UP,Vector2.DOWN,Vector2.LEFT,Vector2.RIGHT]:
			draw_line(knob+d*6,knob+d*14,Color(0.1,0.1,0.1,0.85),2.5)

func _draw_menu() -> void:
	# Full-screen title poster; the gear in its top-right corner opens settings, any other tap starts.
	if menu_art: draw_texture_rect(menu_art,Rect2(0,0,540,960),false)
	else: draw_rect(Rect2(0,0,540,960),INK)

func _crate_icon(c: Vector2,col: Color) -> void:
	# Line-art supply crate, same weight as the settings gear on the poster.
	var w:=2.6
	var front:=PackedVector2Array([c+Vector2(-20,-6),c+Vector2(14,-6),c+Vector2(14,20),c+Vector2(-20,20),c+Vector2(-20,-6)])
	draw_polyline(front,col,w,true)
	draw_polyline(PackedVector2Array([c+Vector2(-20,-6),c+Vector2(-12,-16),c+Vector2(22,-16),c+Vector2(14,-6)]),col,w,true)
	draw_polyline(PackedVector2Array([c+Vector2(22,-16),c+Vector2(22,10),c+Vector2(14,20)]),col,w,true)
	draw_line(c+Vector2(-20,7),c+Vector2(14,7),col,w,true)
	draw_rect(Rect2(c+Vector2(-6,3),Vector2(6,8)),col)

func _chip_text(label: String,rect: Rect2,col: Color) -> void:
	var size:=13
	while font.get_string_size(label,HORIZONTAL_ALIGNMENT_LEFT,-1,size).x>rect.size.x-6 and size>8: size-=1
	_text_center(label,rect.get_center()+Vector2(0,size*0.38),size,col)

func _draw_lootbox() -> void:
	var lang: String=game.language_code
	# Keep the real 3D case visible; only the header and reward console are overlaid.
	draw_rect(Rect2(0,0,540,110),Color(0.018,0.022,0.023,0.84))
	draw_rect(Rect2(0,704,540,256),Color(0.018,0.022,0.023,0.90))
	_button(Rect2(24,24,100,48),"‹  "+game.localize("back"),false)
	_text_center(ShopText.text(lang,"cases_title"),Vector2(328,61),26,WHITE)
	_text_center("DF–07  /  FIELD ISSUE",Vector2(270,132),13,MUTED)
	if game.lootbox_scene.revealed:
		_text_center(ShopText.text(lang,"case_reward"),Vector2(270,742),15,GOLD)
		_bold_text(game.lootbox_reward_title,Vector2(130,778),25,WHITE)
	elif game.lootbox_scene.opening:
		_text_center(ShopText.text(lang,"case_opening"),Vector2(270,756),21,WHITE)
	else:
		_text_center(ShopText.text(lang,"case_hint"),Vector2(270,752),16,MUTED)
	if not game.lootbox_message.is_empty(): _text_center(game.lootbox_message,Vector2(270,786),14,Color("ef9b82"))
	var action: String=ShopText.text(lang,"case_again" if game.lootbox_scene.revealed else "case_open")
	_button(Rect2(80,790,380,66),action+"  ·  "+str(game.LOOTBOX_COST)+" "+ShopText.text(lang,"coins"),false)
	_text_center(ShopText.text(lang,"case_balance")+": "+str(game.bank_coins),Vector2(270,889),16,GOLD)

func _draw_settings() -> void:
	draw_rect(Rect2(0,0,540,960),Color(0.018,0.022,0.023,0.88))
	_bold_text("SETTINGS",Vector2(42,100),32,WHITE)
	_text("AUDIO / GAMEPLAY",Vector2(44,132),14,MUTED)
	_button(Rect2(66,220,408,70),"SFX  /  "+("OFF" if game.sound.muted else "ON"),false)
	_button(Rect2(66,316,408,70),game.localize("reload_auto") if game.auto_reload else game.localize("reload_manual"),false)
	_button(Rect2(66,412,408,70),"文   "+game.localize("language"),false)
	var lang: String=game.language_code
	var sep: String="：" if lang in ["zh_CN","zh_TW","ja"] else ": "
	_button(Rect2(66,508,408,70),"Aa   %s%s%s"%[ShopText.text(lang,"text_size"),sep,ShopText.text(lang,"ts_%d"%game.text_size)],false)
	_button(Rect2(66,810,408,64),game.localize("back"),true)

func _draw_character_select() -> void:
	# Main screen. The 3D survivor and pet stand in the middle (lobby_scene_3d.gd); this draws the
	# frame: one column on the left with 角色 / 宠物 tabs over a vertically scrolling list.
	var lang: String=game.language_code
	draw_rect(Rect2(0,0,540,104),Color(0.015,0.018,0.019,0.72))
	draw_rect(Rect2(0,812,540,148),Color(0.015,0.018,0.019,0.78))
	_wallet(game.WALLET_LOBBY)
	if game.offer_active() and game.state=="character_select": _offer_badge(game.OFFER_BADGE)
	if game.state=="character_select":
		_side_button(game.SIDE_SIGNIN,"signin",ProgressCatalog.text(lang,"signin"),game.signin_available())
		_side_button(game.SIDE_TASKS,"tasks",ProgressCatalog.text(lang,"tasks"),game.missions_ready_count()>0)
		_side_button(game.SIDE_SHOP,"shop",game.localize("shop"),false)
		_side_button(game.SIDE_STORE,"store",StoreCatalog.text(lang,"store"),false)
	_gear_icon(Vector2(501,45))
	for t in range(2):
		var tab: Rect2=game.lobby_tab_rect(t); var tab_on: bool=game.lobby_tab==t
		_text_center(ShopText.text(lang,"chars" if t==0 else "pets"),Vector2(tab.get_center().x,tab.end.y-12),14,WHITE if tab_on else MUTED)
		if tab_on: draw_rect(Rect2(tab.position.x+6,tab.end.y-4,tab.size.x-12,3),RED)
	var view: Rect2=game.lobby_view_rect()
	for i in range(game.lobby_item_count()):
		var card: Rect2=game.lobby_card_rect(i)
		if card.intersects(view): _lobby_card(card,i,view,lang)
	var max_scroll: float=game.lobby_max_scroll()
	if max_scroll>0.0:
		# Thin scroll indicator so it is clear the list goes on.
		var bar_h: float=view.size.y*view.size.y/(view.size.y+max_scroll)
		var bar_y: float=view.position.y+(view.size.y-bar_h)*game.lobby_scroll/max_scroll
		draw_rect(Rect2(view.end.x+2,bar_y,3,bar_h),Color(1,1,1,0.35))
	# Switch arrows beside the survivor.
	_text_center("‹",Vector2(146,492),56,Color(1,1,1,0.85))
	_text_center("›",Vector2(394,492),56,Color(1,1,1,0.85))
	var name: String=game.lobby.CHARACTERS[game.character_choice].name
	_bold_text(name,Vector2(270-bold.get_string_size(name,HORIZONTAL_ALIGNMENT_LEFT,-1,30).x*0.5,790),30,WHITE)
	_text_center(ShopText.text(lang,"drag"),Vector2(270,806),11,MUTED)
	if game.lobby_toast>0.0:
		var a: float=minf(1.0,game.lobby_toast*2.0)
		_panel(Rect2(170,600,200,46),Color(0.02,0.025,0.026,0.92*a),Color(RED,a),0)
		_text_center(ShopText.text(lang,"coming"),Vector2(270,630),16,Color(1,1,1,a))
	_button(Rect2(66,836,408,76),game.localize("start")+"   ›",true)

## One card of the scrolling list, cut off cleanly where it leaves the visible area.
func _lobby_card(card: Rect2,i: int,view: Rect2,lang: String) -> void:
	var vis:=card.intersection(view)
	if vis.size.y<4.0: return
	var whole: bool=vis.size.y>=card.size.y-0.5
	var pets: bool=game.lobby_tab==1
	if not pets and i>=game.lobby.CHARACTERS.size():
		if whole: _locked_slot(card)
		else: _panel(vis,Color(0.04,0.045,0.047,0.80),Color(LINE,0.7),0)
		return
	var on: bool=(game.pet_equipped and game.pet_choice==i) if pets else (game.character_choice==i)
	_panel(vis,Color(0.10,0.11,0.115,0.94) if on else Color(0.05,0.055,0.06,0.80),RED if on and whole else LINE,0)
	var tex: Texture2D=null
	if pets: tex=pet_portraits[i] if pet_portraits.size()>i else null
	else: tex=portraits[i] if portraits.size()>i else null
	var r:=Rect2(card.position+Vector2(4,4),card.size-Vector2(8,30))
	var vr:=r.intersection(view)
	if tex and vr.size.y>1.0:
		var ts:=tex.get_size()
		clean_ops.append(["region",tex,vr,Rect2((vr.position-r.position)/r.size*ts,vr.size/r.size*ts)])
	if card.end.y-24.0>=view.position.y and card.end.y-2.0<=view.end.y:
		var label: String=game.lobby.PETS[i].name if pets else game.lobby.CHARACTERS[i].name
		_text_center(label,Vector2(card.get_center().x,card.end.y-9),11 if pets else 12,WHITE if on else MUTED)
		if on: _brush_underline(Rect2(card.position.x-4,card.end.y-8,card.size.x+8,14))

func _locked_slot(rect: Rect2,pet:=false) -> void:
	_panel(rect,Color(0.04,0.045,0.047,0.80),Color(LINE,0.7),0)
	var c:=rect.get_center()+Vector2(0,-8)
	if pet:
		# Paw print.
		draw_circle(c+Vector2(0,8),11,Color(1,1,1,0.22))
		for o in [Vector2(-13,-6),Vector2(-5,-14),Vector2(5,-14),Vector2(13,-6)]: draw_circle(c+o,4.5,Color(1,1,1,0.22))
	else:
		# Padlock.
		draw_rect(Rect2(c+Vector2(-12,-2),Vector2(24,20)),Color(1,1,1,0.22))
		draw_arc(c+Vector2(0,-2),8,PI,TAU,16,Color(1,1,1,0.22),3.0)
	_text_center(ShopText.text(game.language_code,"coming"),Vector2(c.x,rect.end.y-10),10,Color(MUTED,0.8))

func _gear_icon(c: Vector2) -> void:
	draw_arc(c,13,0,TAU,24,WHITE,3.0)
	for i in range(8):
		var a:=i*TAU/8.0
		draw_line(c+Vector2(cos(a),sin(a))*13,c+Vector2(cos(a),sin(a))*19,WHITE,5.0)
	draw_circle(c,5,WHITE)

func _character_card(rect: Rect2,index: int) -> void:
	_panel(rect,Color("181b1c"),WHITE if game.character_choice==index else LINE,0)
	if portraits.size()>index and portraits[index]:
		clean_ops.append(["texture",portraits[index],Rect2(rect.position+Vector2(3,3),Vector2(rect.size.x-6,rect.size.y-61))])
	draw_rect(Rect2(rect.position+Vector2(3,rect.size.y-58),Vector2(rect.size.x-6,55)),Color(0.025,0.03,0.031,0.96))
	_text_center("男" if index==0 else "女",rect.position+Vector2(rect.size.x/2,rect.size.y-20),22,WHITE)
	if game.character_choice==index:
		draw_rect(Rect2(rect.position,Vector2(5,rect.size.y)),RED)
		draw_rect(Rect2(rect.position,Vector2(rect.size.x,4)),WHITE)

func _hex_badge(center: Vector2,radius: float,value: String) -> void:
	var points:=PackedVector2Array()
	for i in range(6):
		var angle:=TAU*i/6.0; points.append(center+Vector2(cos(angle),sin(angle))*radius)
	draw_colored_polygon(points,Color(0.04,0.05,0.05,0.88)); points.append(points[0]); draw_polyline(points,LINE,1.5,true)
	_text_center(value,center+Vector2(0,6),17,WHITE)

func _draw_shop() -> void:
	# The 3D window between the panels is a close-up of the gear being upgraded.
	draw_rect(Rect2(0,0,540,118),Color(0.02,0.025,0.026,0.80)); draw_rect(Rect2(0,594,540,366),Color(0.018,0.022,0.023,0.88))
	_button(Rect2(24,24,100,48),"‹  "+game.localize("back"),false)
	_bold_text(game.localize("shop_title"),Vector2(150,62),24,WHITE)
	var lang: String=game.language_code
	_text(ShopText.text(lang,"pick"),Vector2(151,91),13,MUTED)
	_button(Rect2(404,24,112,48),ShopText.text(lang,"cases"),true)
	_wallet(game.WALLET_SHOP)
	# plain entry into the store, next to the balance
	var sb: Rect2=game.SHOP_STORE_BTN
	var st:=StoreCatalog.text(game.language_code,"store").to_upper()+"  ›"
	var sw:=bold.get_string_size(st,HORIZONTAL_ALIGNMENT_LEFT,-1,_scaled(22)).x
	_clean_text(bold,Vector2(sb.end.x-sw,sb.get_center().y+8),st,22,HILITE)
	_box(Rect2(sb.end.x-sw,sb.get_center().y+15,sw,3),Color(HILITE,0.85))
	if game.shop_items.is_empty(): return
	var item: Dictionary=game.shop_items[game.shop_index]
	var level: int=game.meta_upgrades.get(item.id,0); var cost: int=game.item_cost(item)
	var maxed: bool=level>=int(item.max_level); var affordable: bool=game.bank_coins>=cost
	# Item card: name, effect, level pips.
	_panel(Rect2(30,642,480,128),Color(0.075,0.08,0.082,0.94),LINE,0); draw_rect(Rect2(30,642,5,128),RED)
	_bold_text(ShopText.text(lang,item.name_key),Vector2(52,684),26,WHITE)
	_text(ShopText.text(lang,item.detail_key),Vector2(53,714),15,MUTED)
	for i in range(int(item.max_level)):
		var pip:=Rect2(53+i*34,734,28,14)
		draw_rect(pip,GOLD if i<level else Color("2b3132"))
	_text("LV %d / %d"%[level,item.max_level],Vector2(232,747),13,GOLD)
	_text("%d / %d"%[game.shop_index+1,game.shop_items.size()],Vector2(452,684),13,MUTED)
	# Prev / upgrade / next.
	_button(Rect2(30,786,80,60),"‹",false)
	_button(Rect2(430,786,80,60),"›",false)
	var label: String
	if maxed: label=ShopText.text(lang,"max")
	else: label="%s  %d %s"%[ShopText.text(lang,"upgrade"),cost,ShopText.text(lang,"coins")]
	_button(Rect2(124,786,292,60),label,affordable and not maxed)
	# Quick-pick chips for every item.
	for i in range(game.shop_items.size()):
		var chip: Dictionary=game.shop_items[i]; var rect:=Rect2(30+i*60,862,56,44); var on: bool=i==game.shop_index
		_panel(rect,Color(0.12,0.13,0.13,0.95) if on else Color(0.07,0.075,0.08,0.90),RED if on else LINE,0)
		_chip_text(ShopText.text(lang,chip.name_key),rect,WHITE if on else MUTED)
	_text_center("PREMIUM / "+game.localize("planned"),Vector2(270,936),12,Color("cf8c75"))

func _draw_languages() -> void:
	draw_rect(Rect2(0,0,540,960),Color(0.018,0.022,0.023,0.88))
	_bold_text(game.localize("language"),Vector2(30,76),30,WHITE); _text("20 LANGUAGES / NATIVE NAMES",Vector2(32,105),10,MUTED)
	_brush_underline(Rect2(26,117,108,14))
	for i in range(Localization.LANGUAGES.size()):
		var item: Dictionary=Localization.LANGUAGES[i]; var rect:=Rect2(30+(i%2)*245,150+floori(i/2.0)*62,235,50); var selected: bool=item.code==game.language_code
		_panel(rect,Color(0.12,0.13,0.13,0.95) if selected else Color(0.07,0.075,0.08,0.90),RED if selected else LINE,0)
		if selected: draw_rect(Rect2(rect.position,Vector2(3,rect.size.y)),RED)
		_text_center(item.native,rect.get_center()+Vector2(0,6),16,WHITE)
	_button(Rect2(66,840,408,60),game.localize("back"),true)

func _draw_gameover() -> void:
	var zh: bool=game.language_code.begins_with("zh")
	# The street where the run ended stays visible; darkness pools at the top (title) and
	# bottom (buttons) only.
	_box(Rect2(0,0,540,960),Color(0.012,0.015,0.016,0.58))
	_box(Rect2(0,0,540,240),Color(0.012,0.015,0.016,0.35))
	_box(Rect2(0,560,540,400),Color(0.012,0.015,0.016,0.45))
	if game.new_record: _draw_new_record()
	else:
		# Red brush splash with white caps — the same section-title language as every menu.
		_section(Vector2(-1,128),game.localize("run_over"),32)
		_clean_center(font,Vector2(270,214),ProgressCatalog.text(game.language_code,"best").replace("%d",_grouped(game.best_distance)),15,MUTED)
	_panel(Rect2(54,238,432,330),Color(0.04,0.045,0.048,0.92),LINE,0)
	_box(Rect2(54,238,4,330),PAINT_RED) # single blood-red edge, like the reference's red marks
	_stat(game.localize("distance"),"%d m"%int(game.distance),Vector2(80,272)); _stat(game.localize("kills"),"%d"%game.kills,Vector2(300,272))
	# Kill breakdown: tougher zombies are worth more coins.
	var lang: String=game.language_code
	var y:=348.0
	for kind in ["banshee","brute","jockey","runner","walker"]:
		var n: int=int(game.kill_counts.get(kind,0))
		if n<=0: continue
		clean_ops.append(["text",font,Vector2(80,y),ShopText.text(lang,"k_"+kind),_scaled(16),Color(1,1,1,0.75)])
		clean_ops.append(["text",font,Vector2(262,y),"× %d"%n,_scaled(16),MUTED])
		var coins:="+%d"%int(game.kill_coins.get(kind,0))
		clean_ops.append(["text",font,Vector2(458-font.get_string_size(coins,HORIZONTAL_ALIGNMENT_LEFT,-1,_scaled(16)).x,y),coins,_scaled(16),GOLD])
		y+=21.0
	clean_ops.append(["text",font,Vector2(80,y),GameText.text(lang,"survival"),_scaled(16),Color(1,1,1,0.75)])
	var surv:="+%d"%game.survival_bonus
	clean_ops.append(["text",font,Vector2(458-font.get_string_size(surv,HORIZONTAL_ALIGNMENT_LEFT,-1,_scaled(16)).x,y),surv,_scaled(16),GOLD])
	draw_rect(Rect2(80,y+12,378,1),Color(1,1,1,0.12))
	_text(GameText.text(lang,"total"),Vector2(80,y+38),16,MUTED)
	var total:="+%d"%(game.last_reward+game.run_double_bonus)
	clean_ops.append(["text",bold,Vector2(80,y+78),total,_scaled(36),GOLD])
	if game.run_double_bonus>0:
		var tw: float=bold.get_string_size(total,HORIZONTAL_ALIGNMENT_LEFT,-1,_scaled(36)).x
		clean_ops.append(["text",bold,Vector2(88+tw,y+78),"×2",_scaled(24),HILITE])
	_text(GameText.text(lang,"wallet")+"  %d"%game.bank_coins,Vector2(80,y+104),14,MUTED)
	if game.last_reward>0:
		var mode:="done" if game.run_double_bonus>0 else ("busy" if game.ad_pending=="run_double" else "ready")
		_ad_x2_button(game.gameover_double_rect(),mode)
	if not game.revive_used:
		_draw_revive_button(Rect2(66,586,408,70))
		# Just the facts next to the revive (no hard sell): a fresh record, or how close it was.
		var nudge:=""
		if game.new_record: nudge=ProgressCatalog.text(lang,"rec_push").replace("%d",_grouped(int(game.distance)))
		elif game.run_start_best>0 and game.record_metres_left()>0 and game.record_metres_left()<=maxi(150,int(game.run_start_best*0.25)):
			nudge=ProgressCatalog.text(lang,"rec_close").replace("%d",str(game.record_metres_left()))
		if nudge!="": _clean_center(bold,Vector2(270,580),nudge,17,HILITE)
	else:
		_text_center("本局复活已使用" if zh else "REVIVE ALREADY USED THIS RUN",Vector2(270,628),16,MUTED)
	_button(Rect2(66,672,408,66),ShopText.text(game.language_code,"to_lobby"),true)
	_button(Rect2(66,758,408,54),game.localize("shop"),false)
	if game.new_record: _record_confetti()

func _draw_pause() -> void:
	draw_rect(Rect2(0,0,540,960),Color(0.015,0.019,0.020,0.78))
	_bold_text(game.localize("paused"),Vector2(114,370),42,WHITE); _brush_underline(Rect2(110,387,104,14))
	_button(Rect2(66,468,408,58),game.localize("reload_auto") if game.auto_reload else game.localize("reload_manual"),false)
	_button(Rect2(66,548,408,68),game.localize("resume"),true)
	_button(Rect2(66,632,408,58),game.localize("shop"),false)
	_button(Rect2(66,708,408,58),game.localize("restart"),false)
	_button(Rect2(66,784,408,58),GameText.text(game.language_code,"main_menu"),false)

func _draw_revive_button(rect: Rect2) -> void:
	# Rewarded-ad revive: opt-in, clearly labelled as an ad, reward stated up front (AdMob policy).
	# Aged brass — the game's "watch an ad" colour — so it never reads as the red main action.
	var zh: bool=game.language_code.begins_with("zh")
	var ad_status: String=game.revival_ads.status if is_instance_valid(game.revival_ads) else "desktop"
	var busy: bool=game.revive_pending or ad_status=="showing"
	var pulse:=0.5+0.5*sin(Time.get_ticks_msec()/1000.0*4.0)
	var bg:=BRASS if not busy else Color(0.22,0.19,0.13,0.96)
	clean_ops.append(["tinted",_pick(brush_button,rect),rect.grow_individual(14,8,14,8),bg if not busy else bg])
	if not busy: _frame(rect.grow_individual(2,2,2,2),Color(1.0,0.9,0.6,0.25+0.30*pulse),1.5)
	_draw_heart_icon(rect.position+Vector2(38,rect.size.y*0.5),BRASS_INK if not busy else MUTED)
	var label:=("看广告复活" if zh else "WATCH AD TO REVIVE")
	var sub:=("恢复 50% 生命，继续本局" if zh else "Continue this run with 50% HP")
	if busy: label=("广告播放中…" if zh else "AD PLAYING…"); sub=""
	elif ad_status=="loading": sub=("广告加载中…" if zh else "Loading ad…")
	elif ad_status=="unavailable": sub=("广告暂不可用，点击重试" if zh else "Ad unavailable — tap to retry")
	var ink: Color=BRASS_INK if not busy else MUTED
	clean_ops.append(["text",bold,rect.position+Vector2(70,44 if sub.is_empty() else 36),label,26,ink])
	if not sub.is_empty(): clean_ops.append(["text",font,rect.position+Vector2(70,58),sub,14,Color(ink.r,ink.g,ink.b,0.8)])
	# "AD" tag so the player always knows a video ad will play: dark chip, brass lettering
	var tag:=Rect2(rect.end.x-58,rect.position.y+20,42,28)
	var tb:=StyleBoxFlat.new(); tb.bg_color=Color(0.10,0.08,0.04,0.95); tb.set_corner_radius_all(4); clean_ops.append(["box",tb,tag])
	var aw:=bold.get_string_size("AD",HORIZONTAL_ALIGNMENT_LEFT,-1,16).x
	clean_ops.append(["text",bold,tag.get_center()+Vector2(-aw/2,6),"AD",16,BRASS_LIGHT if not busy else MUTED])

## Rewarded-ad "×2" button: solid yellow with a play mark and an AD tag, so it is obviously
## tappable and obviously an ad. Modes: ready, busy (ad playing), done (already doubled).
func _ad_x2_button(r: Rect2,mode:="ready") -> void:
	var lang: String=game.language_code
	if mode=="done":
		_box(r,Color(1,1,1,0.06))
		var cc:=r.position+Vector2(26,r.size.y*0.5)
		clean_ops.append(["line",PackedVector2Array([cc+Vector2(-9,0),cc+Vector2(-3,7),cc+Vector2(10,-8)]),HILITE,4.0])
		_clean_text(bold,r.position+Vector2(46,r.size.y*0.5+8),ProgressCatalog.text(lang,"doubled"),20,Color(1,1,1,0.6),false)
		return
	var busy: bool=mode=="busy"
	var pulse:=0.5+0.5*sin(Time.get_ticks_msec()/1000.0*4.0)
	var fill: Color=HILITE if not busy else Color(HILITE.r*0.55,HILITE.g*0.55,HILITE.b*0.4)
	if not busy and glow_tex: clean_ops.append(["tinted",glow_tex,r.grow(26),Color(HILITE.r,HILITE.g,HILITE.b,0.10+0.14*pulse)])
	_box(Rect2(r.position+Vector2(0,4),r.size),Color(0,0,0,0.55))
	_box(r,fill)
	_box(Rect2(r.position,Vector2(r.size.x,3)),Color(1,0.93,0.62,1.0) if not busy else fill)
	# play mark in a dark disc
	var c:=r.position+Vector2(28,r.size.y*0.5)
	var disc:=PackedVector2Array()
	for i in range(20): disc.append(c+Vector2(cos(TAU*i/20.0),sin(TAU*i/20.0))*15.0)
	clean_ops.append(["poly",disc,INK_DARK])
	clean_ops.append(["poly",PackedVector2Array([c+Vector2(-5,-8),c+Vector2(9,0),c+Vector2(-5,8)]),fill])
	var label: String=ProgressCatalog.text(lang,"ad_playing" if busy else "ad_x2")
	var size:=22
	while bold.get_string_size(label,HORIZONTAL_ALIGNMENT_LEFT,-1,_scaled(size)).x>r.size.x-64 and size>12: size-=1
	_clean_text(bold,Vector2(r.position.x+52,r.get_center().y+_scaled(size)*0.36),label,size,INK_DARK,false)
	# small AD tag on the corner
	var tag:=Rect2(r.end.x-30,r.position.y-9,34,20)
	_box(tag,INK_DARK)
	_clean_center(bold,Vector2(tag.get_center().x,tag.get_center().y+6),"AD",13,HILITE)

## Swap-mission-by-ad: dark square with a yellow circular arrow and a small AD tag.
func _swap_ad_button(r: Rect2,busy:=false) -> void:
	_box(r,Color(1,1,1,0.10) if not busy else Color(1,1,1,0.04))
	_box(Rect2(r.position,Vector2(r.size.x,2)),Color(HILITE,0.8))
	var c:=r.get_center()+Vector2(0,2)
	var arc:=PackedVector2Array()
	for i in range(15):
		var a: float=-PI*0.35+TAU*0.78*i/14.0
		arc.append(c+Vector2(cos(a),sin(a))*10.0)
	var col: Color=HILITE if not busy else Color(HILITE,0.4)
	clean_ops.append(["line",arc,col,3.0])
	var tip: Vector2=arc[arc.size()-1]
	clean_ops.append(["poly",PackedVector2Array([tip+Vector2(-1,-7),tip+Vector2(8,1),tip+Vector2(-3,6)]),col])
	var tag:=Rect2(r.end.x-22,r.position.y-8,26,16)
	_box(tag,HILITE)
	_clean_center(bold,Vector2(tag.get_center().x,tag.get_center().y+5),"AD",11,INK_DARK)

## Quiet secondary button: dark fill, thin light top edge, white label.
func _plain_button(r: Rect2,label: String) -> void:
	_box(Rect2(r.position+Vector2(0,4),r.size),Color(0,0,0,0.45))
	_box(r,Color(0.16,0.16,0.16,1.0))
	_box(Rect2(r.position,Vector2(r.size.x,2)),Color(1,1,1,0.35))
	_clean_center(bold,Vector2(r.get_center().x,r.get_center().y+8),label,22,WHITE)

func _draw_heart_icon(c: Vector2,col:=WHITE) -> void:
	var shape:=_heart_points(c,40)
	clean_ops.append(["poly",shape,col])
	var outline:=shape.duplicate(); outline.append(shape[0]); clean_ops.append(["line",outline,col,2.0])
	clean_ops.append(["line",PackedVector2Array([c+Vector2(-7,0),c+Vector2(7,0)]),Color("e23a35") if col!=WHITE else WHITE,3.0])
	clean_ops.append(["line",PackedVector2Array([c+Vector2(0,-7),c+Vector2(0,7)]),Color("e23a35") if col!=WHITE else WHITE,3.0])

func _stat(label: String,value: String,pos: Vector2) -> void:
	# Results must be easy to read: drawn without the worn-paint erosion. Small quiet label,
	# big confident number — the Dead Island results hierarchy.
	clean_ops.append(["text",font,pos,label.to_upper(),_scaled(14),MUTED])
	clean_ops.append(["text",bold,pos+Vector2(0,48),value,_scaled(44),WHITE])

func _icon_button(rect: Rect2,label: String) -> void:
	_panel(rect,Color(0.02,0.025,0.026,0.80),Color(0.32,0.34,0.34,0.65),0); _text_center(label,rect.get_center()+Vector2(0,4),10,WHITE)

## Same rect always picks the same stroke, different rects get different strokes.
func _pick(list: Array[Texture2D],rect: Rect2) -> Texture2D:
	return list[absi(int(rect.position.x*7.0+rect.position.y*13.0+rect.size.x))%list.size()]

func _button(rect: Rect2,label: String,primary: bool) -> void:
	# Hierarchy like the Dead Island menus: the screen's main action is a single red paint
	# stroke; everything secondary is a flat charcoal plate with a hairline frame (no brush,
	# lighter type), so red stays rare and meaningful.
	var size:=_scaled(30 if rect.size.y>=56 else 24)
	var f: Font=bold if primary else font
	while f.get_string_size(label,HORIZONTAL_ALIGNMENT_LEFT,-1,size).x>rect.size.x-20 and size>14: size-=1
	var width:=f.get_string_size(label,HORIZONTAL_ALIGNMENT_LEFT,-1,size).x
	if primary:
		var paint:=rect.grow_individual(14,8,14,8)
		clean_ops.append(["tinted",_pick(brush_button,rect),paint,PAINT_RED])
		clean_ops.append(["text",f,rect.get_center()+Vector2(-width/2+2,size*0.36+2),label,size,Color(0,0,0,0.5)])
		clean_ops.append(["text",f,rect.get_center()+Vector2(-width/2,size*0.36),label,size,WHITE])
	else:
		_box(rect,PLATE,Color(1,1,1,0.22),1)
		clean_ops.append(["text",f,rect.get_center()+Vector2(-width/2,size*0.36),label,size,Color("ddd9cf")])

func _brush_underline(rect: Rect2,color:=PAINT_RED) -> void:
	draw_texture_rect(_pick(brush_line,rect),rect,false,color)

func _panel(rect: Rect2,bg: Color,border: Color,radius: int) -> void:
	# Flat translucent plate (the scene stays readable behind it). Selected/highlighted panels
	# get a red brush underline or a thin frame instead of another smear of paint.
	_box(rect,bg)
	if border.is_equal_approx(RED):
		draw_texture_rect(_pick(brush_line,rect),Rect2(rect.position.x-6,rect.end.y-12,rect.size.x+12,18),false,PAINT_RED)
	elif border!=LINE and border.a>0.05 and not border.is_equal_approx(Color(LINE,0.7)):
		_frame(rect,border,2.0)
	else:
		_frame(rect,Color(1,1,1,0.10),1.0)

func _text(value: String,pos: Vector2,size: int,color: Color) -> void:
	size=maxi(size,12); _string(font,pos,value,size,color)

func _bold_text(value: String,pos: Vector2,size: int,color: Color) -> void:
	size=maxi(size,12); _string(bold,pos,value,size,color)

func _text_center(value: String,pos: Vector2,size: int,color: Color) -> void:
	# Big centred text is a headline: use the heavy poster face.
	size=maxi(size,12); var f: Font=bold if size>=30 else font
	var width:=f.get_string_size(value,HORIZONTAL_ALIGNMENT_LEFT,-1,_scaled(size)).x
	_string(f,pos-Vector2(width/2,0),value,size,color)

func _text_right(value: String,pos: Vector2,size: int,color: Color) -> void:
	size=maxi(size,12); var width:=font.get_string_size(value,HORIZONTAL_ALIGNMENT_LEFT,-1,_scaled(size)).x
	_string(font,pos-Vector2(width,0),value,size,color)

func _multiline(value: String,pos: Vector2,width: float,size: int,color: Color) -> void:
	size=_scaled(maxi(size,13)); draw_multiline_string(font,pos,value,HORIZONTAL_ALIGNMENT_LEFT,width,size,3,color)

## ---- Wallet, store, offers, check-in, missions -------------------------------------------------
## Same visual language as the rest of the game (brush-painted panels and buttons, worn paint):
## red brush slabs for section titles, dark painted panels, thin white outlines for what is
## selected or ready, yellow for highlights and deals, muted painted tiles. No rounded boxes.
const VOUCHER_COL:=Color("e8ddd0")
const HILITE:=Color("c9a24b")          # aged gold highlight (deals, today, ready) — not pure yellow
const INK_DARK:=Color("16130d")        # dark text on gold
const PANEL_TINT:=Color(0.055,0.06,0.065,0.94)

static func _grouped(n: int) -> String:
	var digits:=str(absi(n)); var out:=""
	for i in range(digits.length()):
		if i>0 and (digits.length()-i)%3==0: out+=","
		out+=digits[i]
	return out

static func _compact(n: int) -> String:
	if n>=1000000000: return "%.2fB"%(n/1000000000.0)
	if n>=1000000: return "%.2fM"%(n/1000000.0)
	return _grouped(n)

static func _clock(seconds: int) -> String:
	return "%02d:%02d:%02d"%[seconds/3600,(seconds/60)%60,seconds%60]

func _clean_text(f: Font,pos: Vector2,value: String,size: int,color: Color,shadow:=true) -> void:
	size=_scaled(size)
	if shadow: clean_ops.append(["text",f,pos+Vector2(1,2),value,size,Color(0,0,0,0.6)])
	clean_ops.append(["text",f,pos,value,size,color])

func _clean_center(f: Font,center: Vector2,value: String,size: int,color: Color) -> void:
	var w:=f.get_string_size(value,HORIZONTAL_ALIGNMENT_LEFT,-1,_scaled(size)).x
	_clean_text(f,Vector2(center.x-w/2,center.y),value,size,color)

## Flat fill (only for full-screen dimming and scroll masks).
func _box(rect: Rect2,bg: Color,border:=Color(0,0,0,0),width:=0,radius:=0) -> void:
	var sb:=StyleBoxFlat.new(); sb.bg_color=bg; sb.set_corner_radius_all(radius)
	if width>0: sb.border_color=border; sb.set_border_width_all(width)
	clean_ops.append(["box",sb,rect])

## Dark painted panel with ragged brush edges.
func _paint(rect: Rect2,col:=PANEL_TINT) -> void:
	clean_ops.append(["tinted",_pick(brush_panel,rect),rect.grow_individual(8,6,8,6),col])

## A single brush stroke (titles, tags, tiles).
func _slab(rect: Rect2,col: Color) -> void:
	clean_ops.append(["tinted",_pick(brush_button,rect),rect.grow_individual(10,5,10,5),col])

## Thin square outline: marks what is selected, ready or on offer.
func _frame(rect: Rect2,col:=WHITE,w:=2.0) -> void:
	clean_ops.append(["line",PackedVector2Array([rect.position,Vector2(rect.end.x,rect.position.y),rect.end,Vector2(rect.position.x,rect.end.y),rect.position]),col,w])

## Brush-stroke label sized to its text; returns where it went.
func _tag(pos: Vector2,label: String,bg:=PAINT_RED,fg:=WHITE,size:=15) -> Rect2:
	var w:=bold.get_string_size(label,HORIZONTAL_ALIGNMENT_LEFT,-1,_scaled(size)).x
	var r:=Rect2(pos,Vector2(w+18,_scaled(size)+12))
	_slab(r,bg)
	_clean_text(bold,r.position+Vector2(9,r.size.y-8),label,size,fg,false)
	return r

## Section title: red brush stroke with white capitals (centred if x<0).
func _section(pos: Vector2,label: String,size:=22) -> void:
	var t:=label.to_upper()
	if pos.x<0:
		var w:=bold.get_string_size(t,HORIZONTAL_ALIGNMENT_LEFT,-1,_scaled(size)).x+18
		pos.x=270.0-w/2
	_tag(pos,t,PAINT_RED,WHITE,size)

## Secondary action: outlined, no fill (the red brush button is the main action).
func _ghost_button(rect: Rect2,label: String,col:=WHITE) -> void:
	_paint(rect,Color(0.03,0.035,0.04,0.85))
	_frame(rect,Color(col,0.85),2.0)
	var size:=22
	while bold.get_string_size(label,HORIZONTAL_ALIGNMENT_LEFT,-1,_scaled(size)).x>rect.size.x-16 and size>12: size-=1
	_clean_center(bold,Vector2(rect.get_center().x,rect.get_center().y+_scaled(size)*0.36),label.to_upper(),size,col)

func _plus_button(rect: Rect2) -> void:
	_frame(rect,Color(1,1,1,0.85),2.0)
	var c:=rect.get_center(); var h:=rect.size.x*0.26
	clean_ops.append(["line",PackedVector2Array([c+Vector2(-h,0),c+Vector2(h,0)]),WHITE,3.0])
	clean_ops.append(["line",PackedVector2Array([c+Vector2(0,-h),c+Vector2(0,h)]),WHITE,3.0])

## Coin and voucher balances with a + beside each (both open the store).
func _wallet(origin: Vector2,plus:=true) -> void:
	var coins:=_compact(game.bank_coins); var vouchers:=_compact(game.bank_vouchers)
	game.wallet_text_w=Vector2(bold.get_string_size(coins,HORIZONTAL_ALIGNMENT_LEFT,-1,_scaled(24)).x,bold.get_string_size(vouchers,HORIZONTAL_ALIGNMENT_LEFT,-1,_scaled(24)).x)
	var w: Dictionary=game.wallet_layout(origin)
	clean_ops.append(["texture",coin_tex,w.coin_icon])
	_clean_text(bold,w.coin_text,coins,24,GOLD)
	clean_ops.append(["texture",voucher_tex,w.v_icon])
	_clean_text(bold,w.v_text,vouchers,24,VOUCHER_COL)
	if plus: _plus_button(w.coin_plus); _plus_button(w.v_plus)

func _toast(y: float) -> void:
	if game.store_toast<=0.0 or game.store_toast_text.is_empty(): return
	var a: float=minf(1.0,game.store_toast*2.0)
	var msg: String=game.store_toast_text
	var tw: float=bold.get_string_size(msg,HORIZONTAL_ALIGNMENT_LEFT,-1,_scaled(18)).x+48.0
	var r:=Rect2(270-tw/2,y,tw,46)
	_paint(r,Color(0.04,0.045,0.05,0.96*a)); _slab(Rect2(r.position.x,r.position.y,6,r.size.y),Color(HILITE,a))
	_clean_center(bold,Vector2(270,y+30),msg,18,Color(1,1,1,a))

## Screen header shared by the store and missions pages: back button, big title, red underline.
func _page_header(title: String) -> void:
	_button(Rect2(24,24,100,48),"‹  "+game.localize("back"),false)
	_clean_text(bold,Vector2(150,64),title.to_upper(),34,WHITE)
	clean_ops.append(["tinted",_pick(brush_line,Rect2(146,72,140,14)),Rect2(146,72,140,14),PAINT_RED])

## ---- Dead Island style building blocks -------------------------------------------------------
## Dimmed scene behind (warm dark wash + faint grain + black ink smear across the top), small
## tilted red brush tags for titles, crisp flat rows, grey capital labels, big white numbers.
func _di_backdrop() -> void:
	# drawn on the base canvas, so the list layer and the header sit on top of it
	# solid: nothing of the lobby scene shows through the store
	draw_rect(Rect2(0,0,540,960),Color(0.055,0.05,0.048,1.0))
	draw_polygon(PackedVector2Array([Vector2(0,0),Vector2(540,0),Vector2(540,960),Vector2(0,960)]),
		PackedColorArray([Color(0.12,0.07,0.05),Color(0.09,0.06,0.05),Color(0.03,0.03,0.03),Color(0.04,0.035,0.033)]))
	if grunge_tex: draw_texture_rect(grunge_tex,Rect2(0,0,540,960),true,Color(1,1,1,0.05))
	# ink smear across the header, a second one fading lower down
	draw_texture_rect(brush_panel[0],Rect2(-80,-40,700,190),false,Color(0,0,0,0.85))
	draw_texture_rect(brush_panel[2],Rect2(-120,860,780,150),false,Color(0,0,0,0.7))

## Small tilted red brush tag with white capitals, like the reference's INVENTORY / QUESTS.
func _di_tag(pos: Vector2,label: String,size:=20,angle:=-0.045) -> Rect2:
	var t:=label.to_upper()
	var w:=bold.get_string_size(t,HORIZONTAL_ALIGNMENT_LEFT,-1,_scaled(size)).x
	var r:=Rect2(Vector2.ZERO,Vector2(w+30,_scaled(size)+16))
	clean_ops.append(["xf",pos,angle])
	clean_ops.append(["tinted",_pick(brush_button,r),r.grow_individual(8,4,14,4),Color("b3221d")])
	clean_ops.append(["text",bold,Vector2(14,r.size.y-9),t,_scaled(size),WHITE])
	clean_ops.append(["xf0"])
	return Rect2(pos,r.size)

## Small grey capitals above a group of rows (MOD / PERKS in the reference).
func _di_label(pos: Vector2,label: String,col:=Color(1,1,1,0.55)) -> void:
	clean_ops.append(["text",bold,pos,label.to_upper(),_scaled(13),col])

## Crisp row: flat translucent dark, optional coloured frame for the active / featured one.
func _di_row(r: Rect2,_frame_col:=Color(0,0,0,0)) -> void:
	# soft dark band that fades out to the right, no outline (like the reference's notices)
	clean_ops.append(["grad",PackedVector2Array([r.position,Vector2(r.end.x,r.position.y),r.end,Vector2(r.position.x,r.end.y)]),
		PackedColorArray([Color(0,0,0,0.62),Color(0,0,0,0.18),Color(0,0,0,0.18),Color(0,0,0,0.62)])])

## Price / action box: white-outlined (yellow for deals), greyed when not available.
func _di_price(r: Rect2,label: String,mode:="buy") -> void:
	# a real button: solid yellow block, dark price text, small drop shadow so it reads as pressable
	if mode=="off":
		_box(r,Color(1,1,1,0.06))
		_box(Rect2(r.position,Vector2(r.size.x,2)),Color(1,1,1,0.12))
		_clean_center(bold,Vector2(r.get_center().x,r.get_center().y+7),label,18,Color(1,1,1,0.4))
		return
	_box(Rect2(r.position+Vector2(0,4),r.size),Color(0,0,0,0.55))
	_box(r,HILITE)
	_box(Rect2(r.position,Vector2(r.size.x,3)),Color(1,0.93,0.62,1.0))
	var size:=26
	while bold.get_string_size(label,HORIZONTAL_ALIGNMENT_LEFT,-1,_scaled(size)).x>r.size.x-16 and size>14: size-=1
	_clean_center(bold,Vector2(r.get_center().x,r.get_center().y+_scaled(size)*0.36),label,size,INK_DARK)

const KIND_TILE:={"coins":Color("5b6638"),"vouchers":Color("7e3447"),"bundle":Color("3d6766"),"offer":Color("7a5a1c")}

func _draw_store() -> void:
	var lang: String=game.language_code
	_di_backdrop()
	var view: Rect2=game.store_view_rect()
	list_clip.position=view.position; list_clip.size=view.size
	var cur: String=game.store_currency if not game.store_currency.is_empty() else StoreCatalog.device_currency()
	# rows go into the clipped list layer
	var saved:=clean_ops; clean_ops=list_ops
	for it in game.store_layout():
		var r: Rect2=game.store_screen_rect(it)
		if not r.intersects(view): continue
		if it.has("header"):
			var key: String={"offer":"limited","bundle":"bundles","coins":"coin_packs","vouchers":"voucher_packs"}[it.header]
			_di_label(r.position+Vector2(2,22),StoreCatalog.text(lang,key),HILITE if it.header=="offer" else Color(1,1,1,0.55))
		else: _store_row(r,it.pack,cur,lang)
	var end_y: float=game.STORE_TOP-game.store_scroll+game.store_content_height()-30.0
	if end_y<view.end.y: _clean_center(font,Vector2(270,end_y),StoreCatalog.text(lang,"note"),12,Color(1,1,1,0.45))
	clean_ops=saved
	var max_scroll: float=game.store_max_scroll()
	if max_scroll>0.0:
		var bar_h: float=view.size.y*view.size.y/(view.size.y+max_scroll)
		var bar_y: float=view.position.y+(view.size.y-bar_h)*game.store_scroll/max_scroll
		_box(Rect2(532,view.position.y,2,view.size.y),Color(1,1,1,0.10)); _box(Rect2(531,bar_y,4,bar_h),Color(1,1,1,0.55))
	# header: back, tilted tag, balances at the top right like the reference's resource counters
	_button(Rect2(20,24,96,46),"‹  "+game.localize("back"),false)
	_di_tag(Vector2(136,30),StoreCatalog.text(lang,"store"),22)
	_wallet(Vector2(300,82),false)
	_toast(870)

## One store row: muted colour tile with the animated pack art, small grey kind label, big
## white amount, extras in small text, price box on the right.
func _store_row(r: Rect2,p: Dictionary,cur: String,lang: String) -> void:
	var kind: String=p.kind
	var owned: bool=bool(p.get("once",false)) and game.store_owned.get(p.id,false)
	_di_row(r)
	if kind=="offer":
		# one yellow bar across the top, title left, saving right (like GATHER  999)
		var bar:=Rect2(r.position,Vector2(r.size.x,30))
		_box(bar,Color(HILITE,0.92))
		_clean_text(bold,bar.position+Vector2(12,23),StoreCatalog.text(lang,"limited").to_upper(),20,INK_DARK,false)
		var d:="-%d%%"%StoreCatalog.discount(p); var dw:=bold.get_string_size(d,HORIZONTAL_ALIGNMENT_LEFT,-1,_scaled(22)).x
		_clean_text(bold,Vector2(bar.end.x-dw-12,bar.position.y+24),d,22,INK_DARK,false)
		r=Rect2(r.position+Vector2(0,30),r.size-Vector2(0,30))
	var tile:=Rect2(r.position+Vector2(8,8),Vector2(r.size.y-16,r.size.y-16))
	var tc: Color=KIND_TILE.get(kind,Color("3d6766"))
	if kind!="coins": _box(tile,Color(tc.r*0.8,tc.g*0.8,tc.b*0.8,0.9))
	_pack_visual(tile.grow(-2),p,false)
	var x: float=tile.end.x+16
	var y: float=r.position.y+30
	var label: String
	match kind:
		"coins": label=StoreCatalog.text(lang,"coin_packs")
		"vouchers": label=StoreCatalog.text(lang,"voucher_packs")
		_: label=StoreCatalog.text(lang,p.name)
	_di_label(Vector2(x,y),label,HILITE if kind=="offer" else Color(1,1,1,0.55))
	if kind in ["coins","vouchers"]:
		var coins: bool=kind=="coins"
		clean_ops.append(["texture",coin_tex if coins else voucher_tex,Rect2(x,y+10,30,30) if coins else Rect2(x-2,y+13,44,27)])
		_clean_text(bold,Vector2(x+(38 if coins else 48),y+38),_grouped(int(p.coins if coins else p.vouchers)),34,WHITE)
		if int(p.bonus)>0: _clean_text(bold,Vector2(x,y+66),"+%d%% %s"%[int(p.bonus),StoreCatalog.text(lang,"bonus").to_upper()],14,HILITE,false)
	else:
		clean_ops.append(["texture",coin_tex,Rect2(x,y+10,26,26)])
		_clean_text(bold,Vector2(x+32,y+33),_grouped(int(p.coins)),26,WHITE)
		clean_ops.append(["texture",voucher_tex,Rect2(x-2,y+46,40,24)])
		_clean_text(bold,Vector2(x+44,y+66),"×%d"%int(p.vouchers),22,WHITE)
		if kind=="offer":
			_clean_text(bold,Vector2(x,y+86),"%s  %s"%[StoreCatalog.text(lang,"ends"),_clock(game.offer_seconds_left())],14,HILITE,false)
		elif bool(p.get("once",false)):
			_clean_text(bold,Vector2(x,y+92),StoreCatalog.text(lang,"once").to_upper(),13,Color("e0453d"),false)
	var pr: Rect2=game.store_price_rect(r,false)
	if owned: _di_price(pr,StoreCatalog.text(lang,"owned"),"off")
	else: _di_price(pr,StoreCatalog.price_text(cur,int(p.tier)),"deal" if kind=="offer" else "buy")

## Price button: a dark plate with a brass frame and brass lettering — spending money is the
## brass action, not the red one. Greyed out when not available.
func _store_price(rect: Rect2,label: String,enabled: bool) -> void:
	var size:=_scaled(26 if rect.size.y>=50 else 22)
	while bold.get_string_size(label,HORIZONTAL_ALIGNMENT_LEFT,-1,size).x>rect.size.x-18 and size>13: size-=1
	if enabled:
		_box(rect,Color(0.10,0.09,0.06,0.94),Color(BRASS,0.9),1.5)
		_clean_center(bold,Vector2(rect.get_center().x,rect.get_center().y+size*0.36),label,size,BRASS_LIGHT)
	else:
		_box(rect,Color(0.06,0.062,0.065,0.88),Color(1,1,1,0.10),1)
		_clean_center(bold,Vector2(rect.get_center().x,rect.get_center().y+size*0.36),label,size,MUTED)

func _bonus_tag(pos: Vector2,bonus: int,lang: String) -> void:
	if bonus<=0: return
	_tag(pos,"+%d%% %s"%[bonus,StoreCatalog.text(lang,"bonus").to_upper()],HILITE,INK_DARK,14)

func _amount(pos: Vector2,coins: bool,value: int,size:=26) -> void:
	var icon:=Rect2(pos+Vector2(0,-size+2),Vector2(size+4,size+4)) if coins else Rect2(pos+Vector2(-2,-size+6),Vector2((size+4)*1.5,size))
	clean_ops.append(["texture",coin_tex if coins else voucher_tex,icon])
	_clean_text(bold,Vector2(icon.end.x+8,pos.y+4),_grouped(value),size,GOLD if coins else VOUCHER_COL)

## ---- Limited-time offer ----------------------------------------------------------------------
## Saving as a yellow brush stroke, like "-60%".
func _discount_flag(pos: Vector2,pct: int,size:=1.0) -> void:
	_tag(pos,"-%d%%"%pct,HILITE,INK_DARK,int(28*size))

func _offer_timer(pos: Vector2,size:=20) -> void:
	var cc:=pos+Vector2(9,-7)
	var ring:=PackedVector2Array()
	for i in range(21): ring.append(cc+Vector2(cos(TAU*i/20.0),sin(TAU*i/20.0))*8.0)
	clean_ops.append(["line",ring,HILITE,2.0])
	clean_ops.append(["line",PackedVector2Array([cc+Vector2(0,-5),cc,cc+Vector2(4,2)]),HILITE,2.0])
	_clean_text(bold,pos+Vector2(24,0),_clock(game.offer_seconds_left()),size,HILITE)

## Lobby shortcut: offer picture, saving and countdown; tap reopens the popup.
func _offer_badge(r: Rect2) -> void:
	var o: Dictionary=StoreCatalog.offer(game.offer_id)
	var pulse:=0.5+0.5*sin(Time.get_ticks_msec()/260.0)
	_paint(r)
	_pack_visual(Rect2(r.position+Vector2(6,6),Vector2(r.size.x-12,r.size.x-12)),o)
	_frame(r,Color(HILITE,0.55+0.45*pulse),2.0)
	_tag(Vector2(r.position.x+r.size.x-50,r.position.y-10),"-%d%%"%StoreCatalog.discount(o),HILITE,INK_DARK,15)
	_clean_center(bold,Vector2(r.get_center().x,r.end.y-6),_clock(game.offer_seconds_left()),13,HILITE)

func _draw_offer_popup() -> void:
	var lang: String=game.language_code
	var o: Dictionary=StoreCatalog.offer(game.offer_id)
	if o.is_empty(): return
	var cur: String=game.store_currency if not game.store_currency.is_empty() else StoreCatalog.device_currency()
	_box(Rect2(0,0,540,960),Color(0,0,0,0.72))
	var p: Rect2=game.OFFER_PANEL
	_paint(p,Color(0.05,0.052,0.056,0.97))
	_section(Vector2(-1,p.position.y+16),StoreCatalog.text(lang,"limited"),24)
	var c: Vector2=game.OFFER_CLOSE.get_center()
	clean_ops.append(["line",PackedVector2Array([c+Vector2(-11,-11),c+Vector2(11,11)]),WHITE,4.0])
	clean_ops.append(["line",PackedVector2Array([c+Vector2(11,-11),c+Vector2(-11,11)]),WHITE,4.0])
	var art_r:=Rect2(p.get_center().x-150,p.position.y+72,300,300)
	_pack_visual(art_r,o)
	_frame(art_r,Color(1,1,1,0.18),1.0)
	_discount_flag(Vector2(art_r.end.x-70,art_r.position.y-12),StoreCatalog.discount(o))
	_clean_center(bold,Vector2(p.get_center().x,art_r.end.y+40),StoreCatalog.text(lang,o.name).to_upper(),32,WHITE)
	var y: float=art_r.end.y+76
	_amount(Vector2(p.position.x+92,y),true,int(o.coins))
	_amount(Vector2(p.position.x+262,y),false,int(o.vouchers))
	var left: String=StoreCatalog.text(lang,"ends")
	var lw:=font.get_string_size(left,HORIZONTAL_ALIGNMENT_LEFT,-1,_scaled(17)).x
	_clean_text(font,Vector2(p.get_center().x-lw-60,y+50),left,17,MUTED,false)
	_offer_timer(Vector2(p.get_center().x-48,y+50),18)
	var was: String=StoreCatalog.text(lang,"was")+" "+StoreCatalog.price_text(cur,int(o.was))
	var ww:=font.get_string_size(was,HORIZONTAL_ALIGNMENT_LEFT,-1,_scaled(15)).x
	var b: Rect2=game.OFFER_BUY
	_clean_text(font,Vector2(b.get_center().x-ww/2,b.position.y-14),was,15,MUTED,false)
	clean_ops.append(["line",PackedVector2Array([Vector2(b.get_center().x-ww/2-2,b.position.y-19),Vector2(b.get_center().x+ww/2+2,b.position.y-19)]),Color(1,0.35,0.3,0.9),2.0])
	_store_price(b,StoreCatalog.price_text(cur,int(o.tier)),true)
	_toast(812)

## Pack picture with a live backdrop: the glow breathes, light rays turn slowly, now and then a
## bright flash rolls through, and sparkles twinkle on top. Pictures are goods-only PNGs.
func _pack_visual(r: Rect2,p: Dictionary,own_bg:=true) -> void:
	var t: float=Time.get_ticks_msec()/1000.0
	var seed: int=hash(String(p.id))
	var phase: float=float(seed%1000)/159.0
	var col: Color=StoreCatalog.GLOW.get(String(p.get("glow","gold")),Color(1,0.72,0.25))
	var pulse: float=0.72+0.28*sin(t*3.0+phase)
	var flash: float=pow(maxf(0.0,sin(t*1.1+phase)),14.0)
	if own_bg: _box(r,Color(0.03,0.032,0.036,1.0))
	var art0: Texture2D=pack_art.get(p.id)
	if String(p.get("kind",""))=="coins" and art0:
		# the illustration carries its own dark backdrop and glow; draw it as-is, square, centred
		var side: float=minf(r.size.x,r.size.y)
		clean_ops.append(["texture",art0,Rect2(r.get_center()-Vector2(side,side)*0.5,Vector2(side,side))])
		return
	var c: Vector2=r.get_center()+Vector2(0,r.size.y*0.06)
	var rays: int=int(p.get("rays",0))
	if rays>0:
		var spin: float=t*0.35+phase
		var radius: float=r.size.x*0.47
		var half: float=PI/rays*0.42
		var rc:=Color(col.r,col.g,col.b,0.24*pulse+0.30*flash)
		for i in range(rays):
			var a: float=spin+TAU*i/rays
			var p1:=c+Vector2(cos(a-half),sin(a-half))*radius
			var p2:=c+Vector2(cos(a+half),sin(a+half))*radius
			clean_ops.append(["poly",PackedVector2Array([c,p1,p2]),rc])
	var g: float=r.size.x*(0.86+0.08*pulse+0.12*flash)
	clean_ops.append(["tinted",glow_tex,Rect2(c-Vector2(g,g)*0.5,Vector2(g,g)),Color(col.r,col.g,col.b,0.85*pulse+0.4*flash)])
	var art: Texture2D=pack_art.get(p.id)
	if art: clean_ops.append(["texture",art,r.grow(-r.size.x*0.07)])
	var count: int=4+rays/2
	for k in range(count):
		var h: int=hash(str(seed)+"s"+str(k))
		var pos:=r.position+Vector2(0.1+0.8*float(h%997)/997.0,0.08+0.6*float((h/997)%991)/991.0)*r.size
		var tw: float=pow(maxf(0.0,sin(t*(1.4+0.33*k)+k*2.1+phase)),4.0)
		if tw<0.03: continue
		var sz: float=(3.0+float(h%5))*(r.size.x/200.0)*(0.6+0.6*tw)
		var sc:=Color(1.0,0.96,0.86,tw)
		clean_ops.append(["line",PackedVector2Array([pos-Vector2(sz,0),pos+Vector2(sz,0)]),sc,2.0])
		clean_ops.append(["line",PackedVector2Array([pos-Vector2(0,sz),pos+Vector2(0,sz)]),sc,2.0])

## ---- Check-in and missions screens ------------------------------------------------------------
func _red_dot(pos: Vector2) -> void:
	var pts:=PackedVector2Array()
	for i in range(16): pts.append(pos+Vector2(cos(TAU*i/16.0),sin(TAU*i/16.0))*7.0)
	clean_ops.append(["poly",pts,Color("e23a35")])

## Lobby side buttons: just a white line icon on a soft dark shadow and a small label, no frame.
func _side_button(r: Rect2,icon: String,label: String,dot: bool) -> void:
	var c:=r.position+Vector2(r.size.x/2,30)
	if glow_tex: clean_ops.append(["tinted",glow_tex,Rect2(c-Vector2(40,40),Vector2(80,80)),Color(0,0,0,0.55)])
	var ic: Color=WHITE
	var ac: Color=HILITE if dot else WHITE
	match icon:
		"signin":
			_frame(Rect2(c-Vector2(16,13),Vector2(32,28)),ic,2.0)
			clean_ops.append(["line",PackedVector2Array([c+Vector2(-16,-5),c+Vector2(16,-5)]),ic,2.0])
			for x in [-8,8]: clean_ops.append(["line",PackedVector2Array([c+Vector2(x,-18),c+Vector2(x,-9)]),ic,3.0])
			clean_ops.append(["line",PackedVector2Array([c+Vector2(-7,4),c+Vector2(-2,9),c+Vector2(8,-1)]),ac,3.0])
		"tasks":
			_frame(Rect2(c-Vector2(14,16),Vector2(28,34)),ic,2.0)
			for k in range(3):
				var y:=-7+k*9
				clean_ops.append(["line",PackedVector2Array([c+Vector2(-8,y),c+Vector2(-5,y+3),c+Vector2(-1,y-3)]),ac,2.0])
				clean_ops.append(["line",PackedVector2Array([c+Vector2(2,y),c+Vector2(9,y)]),ic,2.0])
		"shop":
			_frame(Rect2(c-Vector2(17,11),Vector2(34,24)),ic,2.0)
			clean_ops.append(["line",PackedVector2Array([c+Vector2(-17,-11),c+Vector2(-11,-18),c+Vector2(17,-18),c+Vector2(17,-11)]),ic,2.0])
			clean_ops.append(["line",PackedVector2Array([c+Vector2(-17,-1),c+Vector2(17,-1)]),ic,2.0])
		"store":
			# the coin, as it is on every balance
			clean_ops.append(["texture",coin_tex,Rect2(c-Vector2(17,17),Vector2(34,34))])
	var ls:=13
	while bold.get_string_size(label.to_upper(),HORIZONTAL_ALIGNMENT_LEFT,-1,_scaled(ls)).x>r.size.x+6 and ls>8: ls-=1
	_clean_center(bold,Vector2(r.get_center().x,r.end.y-6),label.to_upper(),ls,WHITE)
	if dot: _red_dot(r.position+Vector2(r.size.x-10,6))

func _reward_line(pos: Vector2,coins: int,vouchers: int,size:=22) -> void:
	var x:=pos.x
	if coins>0:
		clean_ops.append(["texture",coin_tex,Rect2(Vector2(x,pos.y-size),Vector2(size+4,size+4))])
		var t:=_grouped(coins); _clean_text(bold,Vector2(x+size+8,pos.y),t,size,GOLD)
		x+=size+16+bold.get_string_size(t,HORIZONTAL_ALIGNMENT_LEFT,-1,_scaled(size)).x
	if vouchers>0:
		clean_ops.append(["texture",voucher_tex,Rect2(Vector2(x,pos.y-size+2),Vector2((size+4)*1.6,size+2))])
		_clean_text(bold,Vector2(x+(size+4)*1.6+6,pos.y),"×%d"%vouchers,size,VOUCHER_COL)

func _draw_signin() -> void:
	var lang: String=game.language_code
	var t: float=Time.get_ticks_msec()/1000.0
	_box(Rect2(0,0,540,960),Color(0,0,0,0.60))
	var p: Rect2=game.SIGNIN_PANEL
	# A military supply drop, not a casino card: one dark plate, stencil day numbers, and a
	# brass frame on the day-7 crate — the only tile allowed to look special.
	_box(p,Color(0.045,0.05,0.052,0.95))
	_frame(p,Color(1,1,1,0.12),1.0)
	_section(Vector2(-1,p.position.y+16),ProgressCatalog.text(lang,"signin"),24)
	_clean_center(font,Vector2(270,p.position.y+66),"SUPPLY CACHE · 7 DAYS",11,MUTED)
	var c: Vector2=game.SIGNIN_CLOSE.get_center()
	clean_ops.append(["line",PackedVector2Array([c+Vector2(-11,-11),c+Vector2(11,11)]),WHITE,4.0])
	clean_ops.append(["line",PackedVector2Array([c+Vector2(11,-11),c+Vector2(-11,11)]),WHITE,4.0])
	var avail: bool=game.signin_available()
	for i in range(ProgressCatalog.SIGNIN.size()):
		var r: Rect2=game.signin_tile(i)
		var reward: Dictionary=ProgressCatalog.SIGNIN[i]
		var done: bool=i<game.signin_index
		var current: bool=avail and i==game.signin_index
		var jackpot: bool=i==6
		_box(r.grow(-4),Color(0.085,0.09,0.092,0.96) if not done else Color(0.05,0.052,0.055,0.92))
		_frame(r.grow(-4),Color(BRASS,0.9) if jackpot else Color(1,1,1,0.14),1.5 if jackpot else 1.0)
		_clean_text(bold,r.position+Vector2(10,24),ProgressCatalog.text(lang,"day").replace("%d",str(i+1)).to_upper(),13,WHITE if current else MUTED,false)
		if jackpot:
			clean_ops.append(["texture",coin_tex,Rect2(r.get_center()+Vector2(-82,-26),Vector2(52,52))])
			clean_ops.append(["texture",voucher_tex,Rect2(r.get_center()+Vector2(4,-20),Vector2(70,42))])
			_clean_center(bold,Vector2(r.get_center().x,r.end.y-14),"%d  +  ×%d"%[int(reward.coins),int(reward.vouchers)],20,BRASS_LIGHT)
		else:
			clean_ops.append(["texture",coin_tex,Rect2(r.get_center()+Vector2(-26,-28),Vector2(52,52))])
			_clean_center(bold,Vector2(r.get_center().x,r.end.y-14),_grouped(int(reward.coins)),20,WHITE)
		if current:
			var pulse:=0.5+0.5*sin(t*4.0)
			_frame(r,Color(1,1,1,0.7+0.3*pulse),2.0)
			_box(Rect2(r.end.x-18,r.position.y+2,14,5),PAINT_RED) # small red issue-mark, no casino glow
		if done:
			_box(r.grow(-4),Color(0,0,0,0.55))
			var cc:=r.get_center()
			clean_ops.append(["line",PackedVector2Array([cc+Vector2(-18,0),cc+Vector2(-5,13),cc+Vector2(20,-14)]),WHITE,6.0])
	if avail:
		_plain_button(game.SIGNIN_CLAIM,ProgressCatalog.text(lang,"claim"))
		_ad_x2_button(game.SIGNIN_DOUBLE,"busy" if game.ad_pending=="signin_double" else "ready")
	else: _ghost_button(Rect2(game.SIGNIN_CLAIM.position,Vector2(game.SIGNIN_DOUBLE.end.x-game.SIGNIN_CLAIM.position.x,game.SIGNIN_CLAIM.size.y)),ProgressCatalog.text(lang,"come_back"),MUTED)
	_toast(712)

func _draw_tasks() -> void:
	var lang: String=game.language_code
	draw_rect(Rect2(0,0,540,960),Color(0.025,0.028,0.03,0.92))
	_page_header(ProgressCatalog.text(lang,"tasks"))
	for t in range(2):
		var r: Rect2=game.tasks_tab_rect(t); var on: bool=game.tasks_tab==t
		if on: _slab(r,PAINT_RED)
		else: _frame(r.grow(-3),Color(1,1,1,0.25),1.0)
		_clean_center(bold,Vector2(r.get_center().x,r.get_center().y+8),ProgressCatalog.text(lang,"daily" if t==0 else "limited").to_upper(),20,WHITE if on else MUTED)
		var ready:=false
		for m in (game.daily_missions() if t==0 else game.event_missions()):
			if game.mission_ready(m,t==0): ready=true
		if ready: _red_dot(r.position+Vector2(r.size.x-8,8))
	var line: String
	if game.tasks_tab==0: line=ProgressCatalog.text(lang,"resets")+"  "+_clock(game.seconds_to_midnight())
	else:
		var secs: int=game.event_seconds_left(); var days: int=secs/86400
		line=ProgressCatalog.text(lang,"event")+"  ·  "+ProgressCatalog.text(lang,"ends")+"  "+(("%dd "%days) if days>0 else "")+_clock(secs%86400)
	_clean_text(bold,Vector2(34,178),line.to_upper(),15,HILITE if game.tasks_tab==1 else MUTED,false)
	for row in game.task_rows():
		var r: Rect2=row.rect; var m: Dictionary=row.m; var daily: bool=row.daily
		var value: int=game.mission_value(m,daily); var goal: int=int(m.goal)
		var claimed: bool=game.mission_claimed(m,daily); var ready: bool=game.mission_ready(m,daily)
		_paint(r)
		if ready: _frame(r.grow(-2),Color(HILITE,0.85),2.0)
		_clean_text(bold,r.position+Vector2(18,38),ProgressCatalog.describe(lang,m).to_upper(),21,Color(1,1,1,0.55) if claimed else WHITE)
		# thin stat bar, like the reference's damage / force bars
		var bar:=Rect2(r.position+Vector2(18,64),Vector2(250,6))
		_box(bar,Color(1,1,1,0.14))
		_box(Rect2(bar.position,Vector2(bar.size.x*float(value)/maxf(1.0,goal),bar.size.y)),HILITE if value>=goal else WHITE)
		_clean_text(bold,Vector2(bar.position.x,bar.end.y+22),"%s / %s"%[_grouped(value),_grouped(goal)],14,MUTED,false)
		_reward_line(Vector2(r.end.x-150,r.position.y+40),int(m.coins),int(m.vouchers),20)
		var b: Rect2=game.task_button(r)
		if game.can_swap_mission(int(row.slot),daily): _swap_ad_button(game.task_swap_button(r),game.ad_pending=="swap:%s:%d"%["daily" if daily else "event",int(row.slot)])
		if claimed: _ghost_button(b,ProgressCatalog.text(lang,"claimed"),Color(1,1,1,0.4))
		elif ready: _store_price(b,ProgressCatalog.text(lang,"claim"),true); _red_dot(b.position+Vector2(b.size.x-2,2))
		else: _ghost_button(b,ProgressCatalog.text(lang,"go"))
	_toast(860)

## ---- New personal best on the death screen -----------------------------------------------------
## A white flash, a gold title that pops in, light rays turning behind it, sparkles, and confetti
## that keeps drifting down over the whole screen.
const CONFETTI_COLORS:=[Color("f2c14e"),Color("e23a35"),Color("ffffff"),Color("ff8a3d"),Color("8fd16a")]

func _draw_new_record() -> void:
	var t: float=game.gameover_time
	var lang: String=game.language_code
	var c:=Vector2(270,150)
	# rays
	var spin: float=t*0.6
	var ray_a: float=0.08+0.3*maxf(0.0,1.0-t)
	for i in range(14):
		var a: float=spin+TAU*i/14.0; var h: float=PI/14.0*0.45
		clean_ops.append(["poly",PackedVector2Array([c,c+Vector2(cos(a-h),sin(a-h)*0.32)*250.0,c+Vector2(cos(a+h),sin(a+h)*0.32)*250.0]),Color(1.0,0.78,0.3,ray_a)])
	if glow_tex:
		var g: float=300.0+30.0*sin(t*3.0)
		clean_ops.append(["tinted",glow_tex,Rect2(c-Vector2(g,g*0.6)*0.5,Vector2(g,g*0.6)),Color(1.0,0.75,0.25,0.55)])
	# title pops in (overshoot), then breathes
	var pop: float=clampf(t/0.35,0.0,1.0)
	var scale: float=lerpf(2.2,1.0,1.0-pow(1.0-pop,3.0))+0.06*sin(t*5.0)*float(pop>=1.0)
	var title: String=ProgressCatalog.text(lang,"new_record")
	_clean_center(bold,c+Vector2(0,18),title,int(54*scale),Color("ffd36b"))
	var best: String=ProgressCatalog.text(lang,"best").replace("%d",_grouped(game.best_distance))
	_clean_center(bold,Vector2(270,214),best,24,WHITE)
	# twinkles around the title
	for k in range(10):
		var ang: float=TAU*k/10.0+t*0.8
		var pos:=c+Vector2(cos(ang)*190.0,sin(ang)*58.0)
		var tw: float=pow(maxf(0.0,sin(t*3.0+k*1.7)),3.0)
		var sz: float=4.0+6.0*tw
		clean_ops.append(["line",PackedVector2Array([pos-Vector2(sz,0),pos+Vector2(sz,0)]),Color(1,0.95,0.8,tw),2.0])
		clean_ops.append(["line",PackedVector2Array([pos-Vector2(0,sz),pos+Vector2(0,sz)]),Color(1,0.95,0.8,tw),2.0])
	# opening flash
	var flash: float=maxf(0.0,0.6-t*1.6)
	if flash>0.0: _box(Rect2(0,0,540,960),Color(1,0.96,0.85,flash),Color(0,0,0,0),0,0)

func _record_confetti() -> void:
	var t: float=game.gameover_time
	for k in range(70):
		var h: int=hash("cf"+str(k))
		var x0: float=float(h%540)
		var speed: float=90.0+float((h/540)%120)
		var delay: float=float((h/7)%100)/100.0*1.2
		var tt: float=t-delay
		if tt<0.0: continue
		var y: float=-20.0+fmod(tt*speed+float(h%300)*0.0,1000.0)
		# a burst upward from the title for the first moment, then a steady fall
		var x: float=x0+sin(tt*2.0+k)*18.0
		if tt<0.6:
			y=150.0-sin(tt/0.6*PI)*120.0+tt*speed*0.5
			x=270.0+(x-270.0)*tt/0.6
		var rot: float=tt*(3.0+float(k%5))
		var col: Color=CONFETTI_COLORS[k%CONFETTI_COLORS.size()]
		var w: float=5.0+float(k%3)*2.0; var hgt: float=9.0
		var d1:=Vector2(cos(rot),sin(rot))*w*0.5; var d2:=Vector2(-sin(rot),cos(rot))*hgt*0.5*(0.25+0.75*absf(cos(tt*4.0+k)))
		var p:=Vector2(x,y)
		clean_ops.append(["poly",PackedVector2Array([p-d1-d2,p+d1-d2,p+d1+d2,p-d1+d2]),col])

## Mid-run banner when the old best is passed: pops in under the distance, rays and a short
## confetti burst, then fades out after a few seconds.
func _draw_record_banner() -> void:
	var t: float=3.0-game.record_banner   # 0 -> 3 s
	var a: float=clampf(game.record_banner/0.6,0.0,1.0)
	var c:=Vector2(270,214)
	var spin: float=t*0.8
	for i in range(12):
		var ang: float=spin+TAU*i/12.0; var h: float=PI/12.0*0.4
		clean_ops.append(["poly",PackedVector2Array([c,c+Vector2(cos(ang-h),sin(ang-h))*Vector2(200,70),c+Vector2(cos(ang+h),sin(ang+h))*Vector2(200,70)]),Color(1,0.78,0.3,0.22*a)])
	var pop: float=clampf(t/0.3,0.0,1.0)
	var sc: float=lerpf(1.8,1.0,1.0-pow(1.0-pop,3.0))
	var lang: String=game.language_code
	_clean_center(bold,Vector2(270,226),ProgressCatalog.text(lang,"new_record")+"  "+_grouped(int(game.distance))+" m",int(30*sc),Color(1,0.84,0.42,a))
	if t<1.4:
		for k in range(36):
			var hsh: int=hash("rb"+str(k))
			var ang2: float=TAU*float(hsh%360)/360.0
			var sp: float=120.0+float((hsh/360)%160)
			var p:=c+Vector2(cos(ang2),sin(ang2)*0.6)*sp*t+Vector2(0,140.0*t*t)
			var col: Color=CONFETTI_COLORS[k%CONFETTI_COLORS.size()]; col.a=clampf(1.4-t,0.0,1.0)
			var rot: float=t*6.0+k
			var d1:=Vector2(cos(rot),sin(rot))*3.5; var d2:=Vector2(-sin(rot),cos(rot))*5.0
			clean_ops.append(["poly",PackedVector2Array([p-d1-d2,p+d1-d2,p+d1+d2,p-d1+d2]),col])

## "Top-up failed" popup: red title stroke, short explanation, Retry / Close.
func _draw_payfail() -> void:
	var lang: String=game.language_code
	_box(Rect2(0,0,540,960),Color(0,0,0,0.72))
	var p: Rect2=game.PAYFAIL_PANEL
	_paint(p,Color(0.05,0.052,0.056,0.98))
	var c:=Vector2(p.get_center().x,p.position.y+70)
	clean_ops.append(["line",PackedVector2Array([c+Vector2(-20,-20),c+Vector2(20,20)]),Color("e0453d"),8.0])
	clean_ops.append(["line",PackedVector2Array([c+Vector2(20,-20),c+Vector2(-20,20)]),Color("e0453d"),8.0])
	_section(Vector2(-1,p.position.y+118),StoreCatalog.text(lang,"pay_failed"),26)
	var msg: String=StoreCatalog.text(lang,"pay_failed_msg")
	var size: int=_scaled(17); var maxw: float=p.size.x-60
	var lines:=[]; var line:=""
	var cjk:=false
	for i in range(msg.length()):
		if msg.unicode_at(i)>0x2E7F: cjk=true; break
	var parts: PackedStringArray=msg.split("") if cjk else msg.split(" ")
	var total: float=font.get_string_size(msg,HORIZONTAL_ALIGNMENT_LEFT,-1,size).x
	var n_lines: int=int(ceil(total/maxw))
	if n_lines>1: maxw=minf(maxw,total/n_lines*1.12)
	for w in parts:
		var trial: String=line+w if cjk or line.is_empty() else line+" "+w
		if font.get_string_size(trial,HORIZONTAL_ALIGNMENT_LEFT,-1,size).x>maxw and not line.is_empty():
			lines.append(line); line=w
		else: line=trial
	if not line.is_empty(): lines.append(line)
	for i in range(lines.size()):
		var lw: float=font.get_string_size(lines[i],HORIZONTAL_ALIGNMENT_LEFT,-1,size).x
		clean_ops.append(["text",font,Vector2(c.x-lw/2,p.position.y+206+i*(size+8)),lines[i],size,Color(1,1,1,0.75)])
	_store_price(game.PAYFAIL_RETRY,StoreCatalog.text(lang,"retry"),true)
	_ghost_button(game.PAYFAIL_CLOSE,StoreCatalog.text(lang,"close"))
