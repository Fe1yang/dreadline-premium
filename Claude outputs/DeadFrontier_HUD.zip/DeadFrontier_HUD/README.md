# Dead Frontier HUD (Godot 4.7.2, gl_compatibility, 540x960 portrait)

The file to edit is **hud.gd**: it draws every 2D screen — title, lobby, store, check-in,
missions, offer pop-up, payment-failed, pause, game over and the in-run HUD.

`reference_only/` holds files hud.gd reads from. Read them, but please don't change them:
- main_3d.gd (`game.` in hud.gd): game state and **tap hit areas**. Button rectangles such as
  SIGNIN_CLAIM, SIGNIN_DOUBLE, SIDE_STORE, store_layout(), gameover_double_rect() and
  task_button() are defined there. If you move a button in hud.gd, the tap area does not move
  with it, so keep each button where its rectangle is (or list the new rectangles so they can
  be updated in main_3d.gd).
- store_catalog.gd / progress_catalog.gd / game_text.gd / shop_text.gd / localization.gd:
  text in 20 languages, pack data and prices.

Please keep:
- every function name main_3d.gd calls on the HUD, and every `game.xxx` it reads;
- the three drawing layers: base canvas, `list_clip` (the scrolling store list), and `clean`
  (everything recorded into clean_ops / list_ops and replayed by _replay);
- the rewarded-ad buttons labelled with an "AD" tag (store policy).
